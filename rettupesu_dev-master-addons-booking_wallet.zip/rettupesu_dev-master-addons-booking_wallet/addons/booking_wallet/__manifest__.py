{
    'name': 'Booking Wallet & Referral',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Booking Wallet',
    'depends': ['base','vehicle_booking_management','firebase_push_notification'],
    'data': [
           'views/booking_wallet.xml',
           'views/driver_inherit.xml',
           'views/min_balance.xml',
           'security/ir.model.access.csv',
         
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
