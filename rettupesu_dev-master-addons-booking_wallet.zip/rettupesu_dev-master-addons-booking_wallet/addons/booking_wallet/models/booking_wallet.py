from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Bookingwallet(models.Model):
    _name = 'wallet.wallet' 
    _rec_name='driver_id'
 
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Booking Wallet'

    driver_id=fields.Many2one('vb.driver.master',string="Driver",track_visibility='onchange',required=True)
    amount_wallet=fields.Float('Wallet Balence',compute='wallet_balance_functions',track_visibility='onchange',store=True)
    total_credit=fields.Float(string='Total Credit Amount',track_visibility='onchange',readonly=True)
    total_debit=fields.Float(string='Total Deduction Amount',track_visibility='onchange',readonly=True)
    total_charity=fields.Float(string="Total Charity Amount",track_visibility='onchange',readonly=True)
    minimum_balance_id=fields.Many2one('minimum.balance',string='Minimum Balance Amount',track_visibility='onchange')
    is_minimum=fields.Boolean(string='Minimum Balance',track_visibility='onchange',compute="minimum_balance_check",store=True,default=False)
    wallet_min_balance = fields.Float(string="Minimum Balance")    
    
    
    #one2many
    booking_wallet_line=fields.One2many('wallet.transaction.line','wallet_id',string='Wallet Line',ondelete='cascade')


    @api.depends('booking_wallet_line')
    def wallet_balance_functions(self):
        credit=0
        debit=0
        charity=0
        for rec in self.booking_wallet_line:
            if rec:
                credit+=rec.credit_price
                self.total_credit=credit
                debit+=rec.deduction_amount
                self.total_debit=debit
                charity+=rec.charity_price
                self.total_charity=charity
                self.amount_wallet=credit-debit-charity
        else:
            self.total_debit=debit
            self.total_credit=credit
            self.total_charity=charity
            self.amount_wallet=credit-debit-charity

    @api.depends('amount_wallet','wallet_min_balance')
    def minimum_balance_check(self):
        for rec in self:
            rec.is_minimum = True if rec.amount_wallet < rec.wallet_min_balance else False


                
class Bookingwalletline(models.Model):
    
    _name='wallet.transaction.line'
    
    s_no=fields.Integer(string='S.No',compute='serial_number_data',store=True)
    wallet_id=fields.Many2one('wallet.wallet',string="Line",ondelete='cascade')
    driver_id=fields.Many2one('vb.driver.master',string="Driver",related='wallet_id.driver_id',store=True)
    mode=fields.Selection([('credit','Credit'),('debit','Debit')],required=True)
    booking_id=fields.Many2one('vb.book.master',string='Booking No' )
    booking_price=fields.Float(string="Booking Price",related='booking_id.price',store=True)
    deduction_percentage=fields.Float(string="Detection in %")
    deduction_amount=fields.Float(string="Detection Amount Per Booking",compute='wallet_balance_function',store=True)
    debit_price=fields.Float(string="Debit Amount",compute='wallet_balance_function',store=True)
    credit_price=fields.Float(string="Credit Amount")
    charity_price=fields.Float(string='Charity Price')

    @api.depends('wallet_id.booking_wallet_line')
    def serial_number_data(self):
        for rec in self:
            no=0
            rec.s_no = no
            for line in rec.wallet_id.booking_wallet_line:
                no +=1
                line.s_no = no    

    @api.depends('wallet_id.booking_wallet_line')
    def wallet_balance_function(self):
        for rec in self:
            if rec.mode=='debit':
                rec.deduction_amount=(rec.booking_price*rec.deduction_percentage/100)
                rec.debit_price=rec.deduction_amount+rec.charity_price

    @api.onchange('booking_id')
    def validate_booking(self):
        for rec in self:
            if rec.booking_id:
                for line in rec:
                    check_book = rec.search([('booking_id', '=', line.booking_id.id)])
                    if len(check_book) >= 1:
                        raise ValidationError(f"Amount Alrady Deducted from this boooking Reference No:{line.booking_id.booking_seq}")  
            
    