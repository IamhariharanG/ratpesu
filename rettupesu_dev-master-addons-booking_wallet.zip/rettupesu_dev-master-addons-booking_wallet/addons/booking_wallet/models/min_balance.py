from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Minimumbalance(models.Model):
    _name = 'minimum.balance' 
    _rec_name='minimum_balance'
 
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Minimum Balance'

    minimum_balance=fields.Float(string="Minimum balance",required=True,track_visibility='onchange')
