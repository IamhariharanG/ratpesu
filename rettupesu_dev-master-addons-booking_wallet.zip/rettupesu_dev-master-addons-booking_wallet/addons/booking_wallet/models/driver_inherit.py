from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError
import requests

class vehicledrivermaster(models.Model):
    _inherit = 'vb.driver.master' 

    amount_wallet=fields.Float(compute='wallet_balance_available',string="Wallet Balance")
    minimum_balance_id=fields.Many2one('minimum.balance',string='Minimum Balance Amount',track_visibility='onchange')


    #Referral
    is_refer=fields.Boolean(string="Is Refer")
    referral_code=fields.Char(string='Refferal Code')
    ref_driver_id=fields.Many2one('vb.driver.master',string='Referred Person')

    def approve_button(self):
        res = super(vehicledrivermaster, self).approve_button()
        if self.state == 'approved':
            #wallet creation
            wallet_check = self.env['wallet.wallet'].search([('driver_id','=',self._origin.id)])
            min_balance = self.env["pre.set.master"].search([("vehicle_category","=",self.vehicle_id.type_id.category.id)]) 
            if not wallet_check:
                wallet_data={
                    'driver_id':self._origin.id,
                    'wallet_min_balance': min_balance.wallet_min_balance,
                    'is_minimum' : True
                }
                create_wallet=self.env['wallet.wallet'].create(wallet_data)
                if create_wallet:
                    credit_transaction=[(0,0,{
                                    'mode':'credit',
                                    'credit_price':300,
                        })]
                    create_wallet.booking_wallet_line=credit_transaction
                driver_content={
                    'name':"Wallet",
                    'driver_id':self._origin.id,
                    'res_users':self._origin.driver_user_id.id,
                    'res_partner_id':self._origin.partner_id.id, 
                    'manager':True,
                    "read_status" : "un_read",
                    "date" : datetime.now().date(),
                    "description":f"Hello {self._origin.name}, your wallet has been created successfully"
                    }
                driver_notification=self.env['notification.list'].create(driver_content)
                one_signal_data = self.env['one.signal.master'].search([('driver_id','=',self._origin.id)])                  
                for data in one_signal_data:
                    doc_key_idss = data.key
                    signal_val = data.signal_type
                    user_mode=data.user_mode
                    
                    if signal_val=='android' and user_mode=='driver':
                        url = "https://onesignal.com/api/v1/notifications"

                        payload = {
                                "include_player_ids":[doc_key_idss],
                                "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                                "contents": {"en": f"Hi {self._origin.name}, you are approved as a driver, and your wallet has been created successfully"},
                                "headings": {"en": "Wallet"},
                                "data": {"foo": "bar"},
                                "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                                "name": "INTERNAL_CAMPAIGN_NAME"
                                }

                        headers = {
                                "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                                'Content-Type': 'application/json; charset=utf-8',
                            }
                        response = requests.post(url, json=payload, headers=headers)
                #Referral
                if self.referral_code:
                    driver = self.search([('driver_seq', '=',self.referral_code)])                 
                    if driver and driver.state=='approved' :
                        self.ref_driver_id=driver.id
                        credit_wallet=self.env['wallet.wallet'].search([('driver_id', '=',driver.id)])
                        if credit_wallet:
                            credit_transaction=[(0,0,{
                                            'mode':'credit',
                                            'credit_price':200,
                                })]
                            credit_wallet.booking_wallet_line=credit_transaction
                            driver_content={
                                'name':"Referral",
                                'driver_id':driver.id,
                                'res_users':driver.driver_user_id.id,
                                'res_partner_id':driver.partner_id.id, 
                                'manager':True,
                                "read_status" : "un_read",
                                "date" : datetime.now().date(),
                                "description":f"Hi {driver.name}, referral money of 200 INR has been credited to your wallet successfully"
                                }
                            driver_notification=self.env['notification.list'].create(driver_content)
                            one_signal_data = self.env['one.signal.master'].search([('driver_id','=',driver.id)])                  
                            for data in one_signal_data:
                                doc_key_idss = data.key
                                signal_val = data.signal_type
                                user_mode=data.user_mode
                                
                                if signal_val=='android' and user_mode=='driver':
                                    url = "https://onesignal.com/api/v1/notifications"

                                    payload = {
                                            "include_player_ids":[doc_key_idss],
                                            "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                                            "contents": {"en": f"Hi {driver.name}, referral money of 200 INR has been credited to your wallet successfully"},
                                            "headings": {"en": "Referral"},
                                            "data": {"foo": "bar"},
                                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                                            "name": "INTERNAL_CAMPAIGN_NAME"
                                            }

                                    headers = {
                                            "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                                            'Content-Type': 'application/json; charset=utf-8',
                                        }
                                    response = requests.post(url, json=payload, headers=headers) 

        return res

    def on_hold_button(self):
        res = super(vehicledrivermaster, self).on_hold_button()
        if self.state == 'on_hold':
            one_signal_data = self.env['one.signal.master'].search([('driver_id','=',self._origin.id)])                  
            for data in one_signal_data:
                doc_key_idss = data.key
                signal_val = data.signal_type
                user_mode=data.user_mode
                
                if signal_val=='android' and user_mode=='driver':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                            "contents": {"en": f"Hi {self.name},We are holding your approval process"},
                            "headings": {"en": "On-Hold"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                            'Content-Type': 'application/json; charset=utf-8',
                        }
                    response = requests.post(url, json=payload, headers=headers) 
        return res
    
    def reject_button(self):
        res = super(vehicledrivermaster, self).reject_button()
        if self.state == 'rejected':
            one_signal_data = self.env['one.signal.master'].search([('driver_id','=',self._origin.id)])                  
            for data in one_signal_data:
                doc_key_idss = data.key
                signal_val = data.signal_type
                user_mode=data.user_mode
                
                if signal_val=='android' and user_mode=='driver':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                            "contents": {"en": f"Hi {self.name},We are rejecting your approval process"},
                            "headings": {"en": "Rejection"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                            'Content-Type': 'application/json; charset=utf-8',
                        }
                    response = requests.post(url, json=payload, headers=headers) 
        return res
    def wallet_balance_available(self):
        balance_wallet = self.env['wallet.wallet'].search([('driver_id', '=',self._origin.id)])
        if balance_wallet:
            for balance in balance_wallet:
                self.amount_wallet=balance.amount_wallet
        else:
            self.amount_wallet=0
    
    def wallet_smart_view(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Wallet',
            'view_mode':'tree,form',
            'res_model':'wallet.wallet',
            'domain': [('driver_id', '=', self.id)],
        }  

    
 
   