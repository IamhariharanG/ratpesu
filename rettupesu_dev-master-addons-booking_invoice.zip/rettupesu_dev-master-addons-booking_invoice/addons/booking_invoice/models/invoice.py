from odoo import models,fields,api,_

class AccountMove(models.Model):
     _inherit = 'account.move' 

   
     booking_id=fields.Many2one('vb.book.master',string="Booking ID")
     cargo_booking_id=fields.Many2one('cargo.booking',string="Cargo Booking ID")
    

class account_move_line(models.Model):
    _inherit = 'account.move.line'

    booking_id=fields.Many2one('vb.book.master',string="Booking ID")
    cargo_booking_id=fields.Many2one('cargo.booking',string="Cargo Booking ID")








