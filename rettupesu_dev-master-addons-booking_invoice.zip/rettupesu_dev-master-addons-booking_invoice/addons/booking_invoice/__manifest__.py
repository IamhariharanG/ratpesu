{
    'name':'Booking Invoice ',
    'version': '14.0.1.0.0',
    'sequence':1,
    'category': 'Custom',
    'depends': ['base','account','vehicle_booking_management','cargo_booking'],
    'data':[
        'views/invoice_view_inherit.xml',
        'reports/header.xml',
        'reports/invoice_report_view.xml',
        'reports/report.xml',
    ],
    
    'installable': True,
    'application': True
 }