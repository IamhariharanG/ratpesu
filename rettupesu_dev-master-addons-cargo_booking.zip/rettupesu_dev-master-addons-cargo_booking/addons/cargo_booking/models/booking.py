from odoo import api,fields,models
from odoo.exceptions import ValidationError
from datetime import datetime

class CargoBook(models.Model):
    _name = "cargo.booking"
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Cargo Booking'
    _rec_name = "cargo_seq"
    
    
    cargo_seq=fields.Char(string='Cargo Sequence')
    #customer
    passenger_id = fields.Many2one("user.master",string="Passenger")  
    book_type_id = fields.Many2one("booking.type",string="Book Type")  
    category_id = fields.Many2one("vehicle.category",string="Vehicle Category")  
    customer_offer_price = fields.Float(string="Customer Offer Price")
    # otp = fields.Integer(string="OTP")
    
    #pick and dest
    pick_latitude = fields.Char(string="Pick Latitude")
    pick_longitude = fields.Char(string="Pick longitude")
    dest_latitude = fields.Char(string="Dest Latitude")
    dest_longitude = fields.Char(string="Dest longitude")
    
    #transit detail  
    schedule_time = fields.Datetime(string="Scheduled Time")
    pickup_location = fields.Char(string="Pickup Location")
    drop_location = fields.Char(string="Drop Location")
    km = fields.Float(string="KM")
    start_time = fields.Datetime(string="Start Time")
    end_time = fields.Datetime(string="End Time")   
    lock_price = fields.Float(string="Bid Price")
    
    #cancel
    cancel_time = fields.Datetime(string="Cancel Time")
    cancel_by = fields.Selection([('driver','Driver'),('passenger','Passenger')] ,string="Cancel By")
    cancel_reason_id=fields.Many2one('booking.cancel.reason',string="Cancel Reason")
    
    #driver
    driver_id = fields.Many2one('vb.driver.master',string="Driver",track_visibility='onchange')
    
    #receiver detail
    receiver_name = fields.Char(string="Receiver Name")
    receiver_phone_number = fields.Char(string="Receiver Phone Number")
    receiver_address = fields.Char(string="Receiver Address")
    receiver_gst_no = fields.Char(string="Receiver GST No")
    e_way_bill_no = fields.Char(string="E-Way Bill No")

    #payment details
    payment_mode= fields.Selection([('online',"Online"),('cash',"Cash")],string="Payment Mode",track_visibility='onchange')
    payment_status= fields.Selection([('paid',"paid"),('process',"Process"),('pending',"Pending")],string="Payment Status",track_visibility='onchange')
    coupon_id = fields.Many2one('coupon.coupon', string="Apply Coupon")
    promotion_id = fields.Many2one('coupon.program', string="Apply Promotion")
    coupon_applied_price = fields.Float(string="Coupon Price")
    price = fields.Float(string="Price",track_visibility='onchange')
    otp = fields.Integer(string="OTP",track_visibility='onchange')

    booking_status= fields.Selection([('schedule',"Scheduled"),('draft',"Draft"),('confirm',"Confirm"),('reached',"Reached"),('transit',"In Transit"),('complete',"Complete"),('done',"Done"),('cancel',"Cancel")],string="Status",track_visibility='onchange',default='draft')
    lift_available= fields.Selection([('yes',"Yes"),('no',"No")],string="Lift Available")
    no_of_floors=fields.Integer(string="No of floors")
    #one2many
    cargo_bidding_line=fields.One2many('cargo.bidding.price','cargo_booking_id',string="Cargo bidding line",ondelete="cascade")
    cargo_image_line = fields.One2many('cargo.image.line','cargo_booking_id',string="Cargo Image line",ondelete="cascade")
    
    is_mobile=fields.Boolean(string="Use my mobile")
    address_mode= fields.Selection([('home',"Home"),('shop',"Shop"),('other',"other")],string="Address ")

    description = fields.Char(string="Description")
    min_bid_amount = fields.Integer(string="Min Bid Amount")
    base_fare = fields.Float(string="Base Fare")
    
    def cargo_channel_creation(self,booking_id=None):
        booking_id=self.search([('id','=',booking_id)])
        if booking_id.booking_status=='confirm':
            passenger_id=booking_id.passenger_id.id
            driver_id=booking_id.driver_id.id

        driver_read = self.env['vb.driver.master'].search([('id','=',int(driver_id))])
        driver_partner_id=driver_read.partner_id.id

        customer_read = self.env['user.master'].search([('id','=',int(passenger_id))])
        customer_partner_id=customer_read.partner_id.id
        
        data = {
            'name' : f"{booking_id.cargo_seq}-Chat",
            'public' : 'groups',
            'cargo_booking_id':booking_id.id
                }
        create_channel = self.env['mail.channel'].sudo().create(data)
        chat_ids=[driver_partner_id,customer_partner_id]
        members = [(5,0,0)]
        for i in chat_ids:
            line_data = {
                        'partner_id' :i,
                    }
            members.append((0,0,line_data))
        create_channel.channel_last_seen_partner_ids=members
    
    def start_trip(self):
        self.start_time = datetime.now()
        self.booking_status = 'transit'        

    
    def end_trip(self):
        self.end_time = datetime.now()
        self.booking_status = 'done' 
        if not self.start_time:
            raise ValidationError("You cannot 'Complete trip' without Started")         
        
        
    def confirm_booking(self):
        self.booking_status = 'confirm'      

            
    def reached_button(self):
        self.booking_status = 'reached'


    def cancel_booking(self):
        self.booking_status='cancel'
        self.cancel_time=datetime.now()
        for rec in self:
            wizard = self.env['cargo.cancel.wizard'].create({'cargo_booking_id':rec._origin.id})
            return {
                'name': 'Cancel Reason',
                'type': 'ir.actions.act_window',
                'res_model': 'cargo.cancel.wizard',
                'view_mode': 'form',
                'target': 'new',
                'res_id': wizard.id,
                'context': "{'create': True}",

            }
        
    
    def cargo_sequence(self):
        self.cargo_seq= f"{'RPC'}{self.env['ir.sequence'].next_by_code('cargo.sequence.create')}"
        
    
    def cargo_base_price(self,distance=None,category_id=None):
        vehicle_types = self.env['pre.set.master'].search([('book_type.vehicle_ride_type','=','cargo'),('vehicle_category','=',category_id)])
        base_fare = int((vehicle_types.cost_per_km * distance)+vehicle_types.booking_fee)
        data = {'base_fair':base_fare,'min_bid_amount':int(base_fare * (vehicle_types.base_fair_discount)),'status':True}
        return data

    class Cargobidingprice(models.Model):

        _name='cargo.bidding.price'
        _rec_name = 'cargo_booking_id'

        cargo_booking_id=fields.Many2one('cargo.booking',string="Cargo bid",ondelete="cascade")
        driver_id = fields.Many2one('vb.driver.master',string="Driver")
        amount = fields.Float(string="Amount")
        request_status= fields.Selection([('yes',"Yes"),('no',"No")],string="Request Status")
    
        km = fields.Float(string="KM")
        
        def conform_book(self):
            self.cargo_booking_id.driver_id = self.driver_id.id
            self.cargo_booking_id.booking_status = 'confirm' 


    class Cargoimage(models.Model):

        _name='cargo.image.line'
        _rec_name = 'cargo_booking_id'

        cargo_booking_id=fields.Many2one('cargo.booking',string="Cargo bid",ondelete="cascade")
        image_attachment=fields.Many2many('ir.attachment',string="Image",ondelete="cascade")
       
    class notification_list(models.Model):
        _inherit='notification.list'

        cargo_booking_id=fields.Many2one('cargo.booking',string="Cargo booking ID")

    
    class Cargobooking_inherit_mailchannels(models.Model):
        _inherit = 'mail.channel'

        cargo_booking_id=fields.Many2one('cargo.booking',string="Cargo Booking ID") 
    
    