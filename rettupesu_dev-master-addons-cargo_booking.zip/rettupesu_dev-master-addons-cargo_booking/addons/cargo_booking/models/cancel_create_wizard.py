from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Cargocancelwizard(models.TransientModel):
    _name='cargo.cancel.wizard'


    cancel_reason_id=fields.Many2one('booking.cancel.reason',string="Cancel Reason")
    cargo_booking_id=fields.Many2one('cargo.booking',string="Cargo Booking ID")
    cancel_by = fields.Selection([('driver','Driver'),('passenger','Passenger')] ,string="Cancel By")
    
   
    def wizard_to_create(self):
        booking = self.env['cargo.booking'].search([('id','=',self.cargo_booking_id.id)])
        if booking:
            booking.cancel_reason_id=self.cancel_reason_id.id
            booking.cancel_by=self.cancel_by
                       