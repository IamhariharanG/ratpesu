{
    'name' : 'Cargo Booking',
    'category' : 'Tools',
    'version' : '14.0.01',
    'summary' : 'Cargo booking for various types',
    'depends' : ['base','vehicle_booking_management','firebase_push_notification'],
    'data' : [
        "views/booking.xml",
        "security/ir.model.access.csv",
        "views/cancel_create_wizard.xml",
              ],
    'image' : [],
    'demo' : [],
    'css' : [],
    'author' : 'Scopex Apps India PVT LTD',
    'installable' : True,
    'auto_install' : False,
    'application' : True
   
 }