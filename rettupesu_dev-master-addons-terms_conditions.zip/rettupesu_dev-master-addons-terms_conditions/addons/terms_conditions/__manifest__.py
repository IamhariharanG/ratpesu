{
    'name': 'TERMS AND CONDITIONS',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'TERMS AND CONDITIONS',
    'depends': ['base','helpdesk'],
    'data': [
          'views/terms_conditions_categories.xml',
          'views/terms_conditions.xml',
          'security/ir.model.access.csv',
         
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
