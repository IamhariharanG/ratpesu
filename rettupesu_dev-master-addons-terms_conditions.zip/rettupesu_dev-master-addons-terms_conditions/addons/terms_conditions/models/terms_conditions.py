from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Termsandconditions(models.Model):
    _name = 'terms.conditions'
    _rec_name = 'category_id'
    _inherit = ['mail.thread','mail.activity.mixin', "image.mixin"]
    _description = "Terms And Conditions" 
   
    category_id = fields.Many2one('terms.conditions.categories',string="Title",track_visibility='onchange')
    sequence_num=fields.Integer(string="Serial No",track_visibility='onchange')
    term_condition = fields.Text(string="Terms And Condition",required=True,track_visibility='onchange')
    user_id = fields.Many2one('res.users', string='User',default=lambda self: self.env.user.id,readonly="1")
    is_user=fields.Boolean(string="Is User",track_visibility='onchange')
    is_driver=fields.Boolean(string="Is Driver",track_visibility='onchange')
    state = fields.Selection([('active', 'Active'),('in_active', 'In Active')],string='Status',required=True,default='active',track_visibility='onchange')
    
    def active(self):
        for rec in self:
            rec.is_active=True
            rec.state='active'

    def in_active(self):
        for rec in self:
            rec.is_active=False
            rec.state='in_active'  
    