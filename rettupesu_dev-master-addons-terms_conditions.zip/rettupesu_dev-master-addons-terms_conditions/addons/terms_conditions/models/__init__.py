from . import terms_conditions
from . import terms_conditions_categories