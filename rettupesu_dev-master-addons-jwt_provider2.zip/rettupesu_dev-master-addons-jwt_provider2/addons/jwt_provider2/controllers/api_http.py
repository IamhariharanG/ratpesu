# -*- coding: utf-8 -*-
from sqlite3 import DatabaseError
import werkzeug
from odoo import http
from odoo.http import request
from odoo.addons.auth_signup.models.res_users import SignupError
from ..JwtRequest import jwt_request
from ..util import is_valid_email
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import datetime
from datetime import timedelta,date
import jwt , requests
import logging
import random
import math
import ast
_logger = logging.getLogger(__name__)

SENSITIVE_FIELDS = ['password', 'password_crypt', 'new_password', 'create_uid', 'write_uid']
SECRET_KEY = "6+8RpZ7ccvF1mPnCV4MDL7/ROLEIBp4f3hqRhvOeTx4="


class JwtController(http.Controller):

    @http.route('/api/http/hello', type='http', auth='public', csrf=False, cors='*')

    @jwt_request.middlewares('api_key')
    def hello(self, **kw):
        return jwt_request.response({ 'message': 'hello!', 'key_info': jwt_request.data.get('key_info') })

    @http.route('/api/http/login', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def login(self, email=None, password=None, **kw):
        email = request.params.get('email')
        password = request.params.get('password')
        token = jwt_request.login(email, password)

        login_email = request.env['res.users'].sudo().search([('login', '=', email)])
        if login_email:
            if token:
                login_orm = request.env['res.users'].sudo().search([('login', '=', email)])
                user_groups = request.env['res.groups'].sudo().search_read([('users','=',login_orm.id)],fields=['full_name'])
                uservar=[i['full_name'] for i in user_groups]

                # currency = request.env.user.currency_id.symbol
                # currency_id = request.env.user.currency_id.id

                valss=[]
                for i in login_orm:
                    date=i['company_ids']
                    for rec in date:
                        valss.append(rec.id)

                res = {
                "accessToken": token,
                "status": "success",
                "message": "Login Successfully",
                'status_message':"success",
                'data': {
                    'email':login_orm['email'],
                    'name':login_orm['name'],
                    'partner_id':login_orm['partner_id'].id,
                    # 'currency':currency,
                    # 'currency_id':currency_id,
                    'user_access':uservar,
                    'allowed_companies':valss,
                    'language':login_orm['lang'],
                    'id':login_orm['id'],
                    'employee_id': login_orm['employee_id'].id,
                    'default_company':login_orm['company_id'].id,
                }
                }
                return res
                
            else:
                res={
                    'status':"failure",
                    'message':"Invalid Email Or Password",
                    'status_message':"invalid"
                }
                return res
        else:
            res={
                'status':"failure",
                'message':"You have not Registered, Please Register.",
                'status_message':"notfound"

            }
            return res


    @http.route('/api/http/me', type='http', auth='public', csrf=False, cors='*')
    @jwt_request.middlewares('jwt')
    def me(self, **kw):
        return jwt_request.response(request.env.user.to_dict())


    @http.route('/api/http/logout', type='http', auth='public', csrf=False, cors='*')
    @jwt_request.middlewares('jwt')
    def logout(self, **kw):
        jwt_request.logout()
        return jwt_request.response()


    @http.route('/api/new_registration', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def new_registration(self, email=None, name=None, password=None,user='user' ,**kw):
        name =request.params.get('name')
        email = request.params.get('email')
        password =request.params.get('password')
        phone_number=request.params.get('mobileno')
        
        '''
        In previous version, we use auth_signup to register an external (portal) user.
        For this demo, we use res.users.create instead, this will create an internal user
        '''
        if not is_valid_email(email):
            return jwt_request.response(status=400, data={'message': 'Invalid email address','status': 'failure'})
        if not name:
            return jwt_request.response(status=400, data={'message': 'Name cannot be empty','status': 'failure'})
        if not password:
            return jwt_request.response(status=400, data={'message': 'Password cannot be empty','status': 'failure'})

        # sign up
        try:
            if request.env['res.users'].sudo().search([('login', '=', email)]):
                return jwt_request.response(status=400, data={'message': 'Email address is already exist','status': 'failure'})

            user = request.env['res.users'].sudo().create({
                'login': email,
                'password': password,
                'name': name,
                'email': email, 
            })
            notification = request.env['order.notification'].sudo().create({
            'name' : 'User Successfully Created!!!',
            'status' : 'created',
            'view_status' : 'unread',
            'partner_id' : user.partner_id.id,
            'user_id' : user.id,
            'description' : f"The User_name <b>{name}</b> has been created and your email is <b>{email}</b>"
                    })
            user = request.env['res.users'].sudo().search([('login', '=', email)])
            if request.env['res.users'].sudo().search([('login', '=', email)]):
                #update mobile number in res partner
                partner = request.env['res.users'].sudo().search_read([('id','=',user.id)],fields=['partner_id'])
                partner_id = partner[0]['partner_id'][0]
                partner = request.env['res.partner'].sudo().browse(int(partner_id)).write({'mobile':phone_number})
                # create token
                token = jwt_request.create_token(user)
                return {
                    'message':'Successfully Login',
                     'status':'success',
                    'user': user.to_dict(),
                    'accessToken': token,
                    'data': {
                    'email':user['email'],
                    'name':user['name'],
                    'partner_id':partner_id,
                    }
                    
                }
        except Exception as e:
            _logger.error(str(e))
            return jwt_request.response_500({
                'message': 'Server error'
            })


    @http.route('/api/http/signup', type='http', auth='public', csrf=False, cors='*', methods=['POST'])
    def register(self, email=None, name=None, password=None, **kw):
        '''
        Sign up using auth_signup modules
        '''
        if not is_valid_email(email):
            return jwt_request.response(status=400, data={'message': 'Invalid email address'})
        if not name:
            return jwt_request.response(status=400, data={'message': 'Name cannot be empty'})
        if not password:
            return jwt_request.response(status=400, data={'message': 'Password cannot be empty'})

        # sign up
        try:
            model = request.env['res.users'].sudo()
            signup = getattr(model, 'signup')
            if signup:
                if request.env['res.users'].sudo().search([('login', '=', email)]):
                    return jwt_request.response(status=400, data={'message': 'Email address is not available'})
                data = {
                    'login': email,
                    'password': password,
                    'name': name,
                    'email': email,
                }
                # signup return a tuple (db, login, password)
                # you can use that to call jwt_request.login(login, password)
                signup(data)
                # but, we just need to retrieve the newly created user
                user = model.search([
                    ('login', '=', email)
                ])
                if user:
                    token = jwt_request.create_token(user)
                    return jwt_request.response({
                        'user': user.to_dict(),
                        'token': token
                    })
                raise Exception()
        except SignupError:
            return jwt_request.response({
                'message': 'Signup is currently disabled',
            }, 400)
        except Exception as e:
            _logger.error(str(e))
            return jwt_request.response_500({
                'message': 'Cannot create user'
            })

    def _response_auth(self, token: str):
        return jwt_request.response({
            'user': request.env.user.to_dict(),
            'token': token,
        })



    
    @http.route('/api/user_access', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def user_access_fun(self):
        token = request.params.get('token')

        token_user_id=request.env['jwt_provider.access_token'].sudo().search_read([('token','=',token)],fields=['user_id'])
        if token_user_id:
            user_id=None
            for user_token in token_user_id:
                user_id=user_token['user_id'][0]

            user_groups = request.env['res.groups'].sudo().search_read([('users','=',user_id)],fields=['full_name'])
            uservar=[i['full_name'] for i in user_groups]

            currency = request.env.user.currency_id.symbol


            return {
                "status":"success",
                "message":uservar
            }
        else:
            return {
                "status":"failure",
                "message":"ivaild token"
            }
            
    @http.route('/api/http/otp', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def otp(self, phone_number=None, **kw):
        phone_number = request.params.get('phone_number')
        sms_code = request.params.get('sms_code')
        type_users = request.params.get('type_users')

        
        new_create_serials = request.env['res.users'].sudo().search_read([('phone_number','=',phone_number)],fields=['id','phone_number','otp','name','login'])

        if new_create_serials:
            otp_create = new_create_serials[0]['id']
            random_otp =  random.randrange(1000, 9999)
            otp = str(random_otp)
            now_1 = datetime.datetime.now()
            result_10 = now_1 + timedelta(minutes=10)
            ts_1 = result_10.timestamp()

            write_otp = request.env['res.users'].sudo().browse(int(otp_create)).write({'otp':otp,'expire_date':ts_1})
            
        else:
            pass

        create_serials = request.env['res.users'].sudo().search_read([('phone_number','=',phone_number)],fields=['id','phone_number','otp','name','login'])

        for k in create_serials:
            user={
                'otp':k['otp']
               
                } 
        if create_serials:
            res= {
 
                    'status':"success",
                    'message':"OTP Sent Successfully",
                    'sms_code':sms_code,
                    'otp':otp,
                }    
            return res
        else: 
            random_otp =  random.randrange(1000, 9999)
            otp = str(random_otp)
            now = datetime.datetime.now()
            result_1 = now + timedelta(minutes=10)
            ts = result_1.timestamp()

            my_data={
                'phone_number':phone_number,
                'otp_number':otp,
                'expire_date':ts,
                'type_users':type_users,
            }
            write_check =  request.env['create.otp'].sudo().search_read([('phone_number','=',phone_number)],fields=['id','phone_number'])
            
            if write_check:
                otp_id=write_check[0]['id']
                write_otp = request.env['create.otp'].sudo().browse(otp_id).write({'otp_number':otp,'expire_date':ts})
            else:
                create_new_user = request.env['create.otp'].sudo().create(my_data)
            

            #write otp in res user
            value = 1234
            # for i in value['data']:
                # status = i['status']
               #INV-NUMBER 
            if value:
                create_otp_1 = request.env['create.otp'].sudo().search_read([('phone_number','=',phone_number)],fields=['otp_number'])
                for k in create_otp_1:
                    otp={
                        'otp_number':k['otp_number']
                        }
                if create_otp_1:
                    res={

                        'status':"newuser",
                        'message':"OTP Sent Successfully",
                        'otp':otp,   
                    }

                    return res
            else:
                return {

                'message':'Invalid phone number',
                'status':'failure'
                }




    @http.route('/api/http/otp_reg', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def otp_reg(self, phone_number=None,otp=None ,**kw):
        phone_number = request.params.get('phone_number')
        otp = request.params.get('otp')
        type_users = request.params.get('type_users')
        data=[]
        user_otp = request.env['create.otp'].sudo().search_read([('phone_number', '=',str(phone_number)),('otp_number', '=',str(otp))],fields=['expire_date'])
        user = request.env['res.users'].sudo().search_read([('phone_number', '=',str(phone_number)),('otp', '=',str(otp))],fields=['id','type_users','email','name','phone_number','partner_id','expire_date'])
        driver_id = request.env['vb.driver.master'].sudo().search([('mobile','=',phone_number)],order="id desc",limit=1)
        passenger_id = request.env['user.master'].sudo().search([('mobile','=',phone_number)])
        
        # for rec in user_otp:
        #     expire_date_otp= rec['expire_date']
        # for res in user:
        #     expire_date = res['expire_date']
        #     user_id = res['id']
        #     type_users = res['type_users']

        # now = datetime.datetime.now()
        # ts = now.timestamp()
        if user:
            if user[0]['type_users'] in [type_users,'admin']:
                # if ts <=expire_date:
                # if expire_date:
                for k in user:
                    user={
                        'id':k['id'],
                        'type_users':k['type_users'],
                        'email':k['email'],
                        'phone_number':k['phone_number'],
                        'name':k['name'],
                        'partner_id':k['partner_id']
                    }

                token = jwt_request.create_token(user,type_users)
                if type_users == 'user' :
                    ress_data =  {
                            'email':passenger_id['email'],
                            'phone_number':passenger_id['mobile'],
                            'name':passenger_id['name'],
                            'id':passenger_id['id'],
                            'partner_id':passenger_id.partner_id.id,
                            'state' : driver_id['state'],
                            'status' : passenger_id['status']
                            }
                elif type_users == 'driver':
                    ress_data =  {
                            'email':driver_id['email'],
                            'phone_number':driver_id['mobile'],
                            'name':driver_id['name'],
                            'id':driver_id['id'],
                            'partner_id':driver_id.partner_id.id,
                            'state' : driver_id['state'],
                            'status' : driver_id['daily_status']
                            }
                if driver_id:
                    ress_data.update({'driver_id' : driver_id.id})
                    ress_data.update({'user_id' : None})
                if passenger_id:
                    ress_data.update({'user_id' : passenger_id.id})
                    ress_data.update({'driver_id' : None})
                    # ress_data.update({'status' : passenger_id.status})
                if passenger_id and driver_id:
                    ress_data.update({'user_id' : passenger_id.id})
                    ress_data.update({'driver_id' : driver_id.id})
                ress = {
                "accessToken": token,
                "message": "OTP Verified Successfully",
                "status": "success",
                'type_users': user['type_users'],
                'data':ress_data
                }

                return ress

                    
            else:
                return {

                'message':'You have not Registered, Please Register',
                'status':'failure',
                'status_message': 'notfound'
                
                }

        elif user_otp :
            # if ts<=expire_date_otp:
            # if expire_date_otp:
            return {

            'message':'You have not Registered, Please Register',
            'status':'failure',
            'status_message': 'notfound'
            
            }
            # else:
            #     return{
            #         'status':"failure",
            #         'message':'OTP Time Expired',
            #         'status_message': 'expired'
            #         }

        else:
            return {

            'message':'Entered OTP Is Invalid',
            'status':'invalid',
            'status_message': 'invalid'
            }
        

    @http.route('/api/http/otp_val', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def otp_val(self, phone_number=None,otp=None ,**kw):
        phone_number = request.params.get('phone_number')
        otp = request.params.get('otp')
        data=[]

        user = request.env['create.otp'].sudo().search_read([('phone_number', '=',str(phone_number)),('otp', '=',str(otp))])
        if user:
            for k in user:
                user={

                    'otp':k['otp']
                }
            ress = {

            "message": "OTP Sent Successfully"
            }

            return ress 
        else:
            return {

            'message':'OTP Is invalid'
            }
            

    @http.route('/api/http/booking_vehicle_id', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def booking_vehicle_id(self, phone_number=None,otp=None ,**kw):
        customer_id = request.params.get('customer_id')
        booking_id = request.params.get('booking_id')
        
#trigger funciton in vb.booking.master  
        booking = request.env['vb.booking.master'].sudo().sudo().browse(int(booking_id)).find_nearby_vehicles( )
        
        return {
                'message':booking
                }

    @http.route('/api/book_attachment', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def book_attachment(self,**kw):
        res_id = request.params.get('res_id')
        file_data = request.params.get('files')
        file_names = request.params.get('file_name')
        data = {
            'name' : file_names,
            'type' : 'binary',
            'datas' : file_data,
            'res_model' : 'vb.booking.master',
            'res_id' : res_id,
            'public' : True,
        }
        attached = request.env['ir.attachment'].sudo().create(data)
        request.env['vb.booking.master'].sudo().browse(res_id).write({'attachment_id':[[4,attached.id]]})

        return {'message' : attached}
    
    @http.route('/api/driver_link',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def driver_link(self):
        driver_id = request.params.get("driver_id")
        call_fuction = request.env['vb.driver.master'].sudo().browse(int(driver_id)).compute_driver_position(driver_id)     
        
        return {
            'message' : 'driver position updated'
            }
    
    @http.route('/api/user_link',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def user_link(self):
        user_id = request.params.get("user_id")
        call_fuction = request.env['user.master'].sudo().browse(int(user_id)).find_nearby_vehicles(user_id)  
        
        return {
            'message' : 'User position updated'
            }
    
    
#user registration


    @http.route('/api/user_registration', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def user_registration(self, email=None, name=None, password=None,user='user' ,**kw):
        name =request.params.get('name')
        email = request.params.get('email')
        phone_number=request.params.get('mobileno')
        gender =request.params.get('gender')
        type_users='user'
        latitude = request.params.get('latitude')
        longitude = request.params.get('longitude')
        referral_code = request.params.get('referral_code')
        
        '''
        In previous version, we use auth_signup to register an external (portal) user.
        For this demo, we use res.users.create instead, this will create an internal user
        '''
        if not is_valid_email(email):
            return jwt_request.response(status=400, data={'message': 'Invalid email address','status': 'failure'})
        if not name:
            return jwt_request.response(status=400, data={'message': 'Name cannot be empty','status': 'failure'})

        # sign up
        try:
            
            if request.env['res.users'].sudo().search([('phone_number', '=', phone_number)]):
                
                # return jwt_request.response(status=400, data={'message': 'Phone Number is already exist','status': 'failure'})
                user = request.env['res.users'].sudo().search([('phone_number', '=', phone_number)])
                partner = request.env['res.users'].sudo().search_read([('id','=',user.id)],fields=['partner_id'])
                partner_id = partner[0]['partner_id'][0]
                #user master creation 
                
                data_users = {
                    'name':name,
                    'email':email,
                    'mobile':phone_number,
                    'password':123,
                    'user_type':'user',
                    'user_id':user.id,
                    'partner_id':partner_id,
                    'longitude':longitude,
                    'latitude':latitude,
                    'gender':gender,
                    'referral_code':referral_code,
                    
                        }
                user_create = request.env['user.master'].sudo().create(data_users)
                user_id=user_create.id
                
                #notification creation
                notification = request.env['notification.list'].sudo().create({
                'name' : 'User Successfully Created!!!',
                'status_id' : 'user_registration',
                'read_status' : 'un_read',
                'res_partner_id' : user.partner_id.id,
                'res_users' : user.id,
                'description' : f"Hello, <b>{name}</b>  🚖 Welcome to Rate Pesu. Book rides conveniently and travel with ease. Enjoy your journey!",
                
                'date' : datetime.datetime.now().date()
                        })
                
                
                if request.env['res.users'].sudo().search([('phone_number', '=', phone_number)]):
                    #update mobile number in res partner
                    partner = request.env['res.partner'].sudo().browse(int(partner_id)).write({'mobile':phone_number})
                    #update user type in res user
                    request.env['res.users'].sudo().browse(int(user.id)).write({'type_users':'admin'})
                    # create token
                    token = jwt_request.create_token(user,type_users)
                    return {
                        'message':'Successfully Login',
                        'status':'success',
                        'user': user.to_dict(),
                        'accessToken': token,
                        'data': {
                        'email':user['email'],
                        'name':user['name'],
                        'partner_id':partner_id,
                        'user_master_id':user_id,
                        "user_id":user['id']
                        }
                        
                    }
      #-----------------------------------------------  
            if request.env['res.users'].sudo().search([('login', '=', email)]):
                return jwt_request.response(status=400, data={'message': 'Email address is already exist','status': 'failure'})    
            #resuser creation
            user = request.env['res.users'].sudo().create({
                'login': email,
                'password': 123,
                'name': name,
                'phone_number':phone_number,
                'email': email,
                'type_users':'user' 
            })
            #get user id 
        
            user = request.env['res.users'].sudo().search([('phone_number', '=', phone_number)])
            partner = request.env['res.users'].sudo().search_read([('id','=',user.id)],fields=['partner_id'])
            partner_id = partner[0]['partner_id'][0]
            #user master creation 
            
            data_users = {
                'name':name,
                'email':email,
                'mobile':phone_number,
                'password':123,
                'user_type':'user',
                'user_id':user.id,
                'partner_id':partner_id,
                'longitude':longitude,
                'latitude':latitude,
                'gender':gender,
                'referral_code':referral_code,
                
                    }
            user_create = request.env['user.master'].sudo().create(data_users)
            user_id=user_create.id
        
            #notification creation
            notification = request.env['notification.list'].sudo().create({
            'name' : 'User Successfully Created!!!',
            'status_id' : 'user_registration',
            'read_status' : 'un_read',
            'res_partner_id' : user.partner_id.id,
            'res_users' : user.id,
            'customer_id':user_create.id,
            'description' : f"Hello, <b>{name}</b>  🚖 Welcome to Rate Pesu. Book rides conveniently and travel with ease. Enjoy your journey!",
            
            'date' : datetime.datetime.now().date()
                    })
            
            
            if request.env['res.users'].sudo().search([('phone_number', '=', phone_number)]):
                #update mobile number in res partner
                partner = request.env['res.partner'].sudo().browse(int(partner_id)).write({'mobile':phone_number})
                # create token
                token = jwt_request.create_token(user,type_users)
                return {
                    'message':'Successfully Login',
                     'status':'success',
                    'user': user.to_dict(),
                    'accessToken': token,
                    'data': {
                    'email':user['email'],
                    'name':user['name'],
                    'partner_id':partner_id,
                    'user_master_id':user_id,
                    "user_id":user['id']
                    }
                    
                }
        except Exception as e:
            _logger.error(str(e))
            return jwt_request.response_500({
                'message': 'Server error'
            })

#driver registration

    @http.route('/api/driver_registration', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def driver_registration(self, email=None, name=None, password=None,user='user' ,**kw):
        name =request.params.get('name')
        email = request.params.get('email')
        phone_number=request.params.get('mobileno')
        city=request.params.get('city')
        type_users='driver'
        latitude = request.params.get('latitude')
        longitude = request.params.get('longitude')
        aadhar = request.params.get('aadhar')
        pan = request.params.get('pan')
        referral_code = request.params.get('referral_code')
        company_name = request.params.get('company_name')
        gender = request.params.get('gender')
        pinky_ponnu = request.params.get('pinky_ponnu')

        if pinky_ponnu == "false":
            pinky_ponnu = False
        else:
            pinky_ponnu = True
        '''
        In previous version, we use auth_signup to register an external (portal) user.
        For this demo, we use res.users.create instead, this will create an internal user
        '''
        if not is_valid_email(email):
            return jwt_request.response(status=400, data={'message': 'Invalid email address','status': 'failure'})
        if not name:
            return jwt_request.response(status=400, data={'message': 'Name cannot be empty','status': 'failure'})
        # sign up
        try:
            
            if request.env['res.users'].sudo().search([('phone_number', '=', phone_number)]):
                
                # return jwt_request.response(status=400, data={'message': 'Phone Number is already exist','status': 'failure'})
                #get user id 
        
                user = request.env['res.users'].sudo().search([('phone_number', '=', phone_number)])
                partner = request.env['res.users'].sudo().search_read([('id','=',user.id)],fields=['partner_id'])
                partner_id = partner[0]['partner_id'][0]
                #user master creation 
                
                data_users = {
                    'name':name,
                    'email':email,
                    'mobile':phone_number,
                    'password':123,
                    'user_type':'driver',
                    'driver_user_id':user.id,
                    'partner_id':partner_id,
                    'longitude':longitude,
                    'latitude':latitude,
                    'res_city':city,
                    'aadhar_no':aadhar,
                    'pan_no':pan,
                    'referral_code':referral_code,
                    'company_name':company_name,
                    "gender" : gender,
                    "pinky_ponnu" : pinky_ponnu,
                    

                        }
                user_create = request.env['vb.driver.master'].sudo().create(data_users)
                
                user_id=user_create.id
                
                data1 = [(0,0,{
                "name" : "Driver License",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                         (0,0,{
                "name" : "Driver License Back",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                         (0,0,{
                "name" : "Vehicle Number Plate",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),(0,0,{
                "name" : "Insurance",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),(0,0,{
                "name" : "Profile Photo With Vehicle",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "RC Book Front",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "RC Book Back",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Driver License",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Driver License Back",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Vehicle Number Plate",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Insurance",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Profile Photo With Vehicle",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "RC Book Front",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "RC Book Back",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create})]
                user_create.attchment_ids = data1
                
            
                # notification creation
                notification = request.env['notification.list'].sudo().create({
                'name' : 'User Successfully Created!!!',
                'status_id' : 'user_registration',
                'read_status' : 'un_read',
                'res_partner_id' : user.partner_id.id,
                'res_users' : user.id,
                'description' : f"Welcome, <b>{name}</b>! 🚗 Start earning with Rate Pesu. Accept ride requests, drive safely, and make money on the go!",
                
                'date' : datetime.datetime.now().date()
                        })
                
                
                
                #update mobile number in res partner
                partner = request.env['res.partner'].sudo().browse(int(partner_id)).write({'mobile':phone_number})
                
                #update user type in res user
                request.env['res.users'].sudo().browse(int(user.id)).write({'type_users':'admin'})
                # create token
                token = jwt_request.create_token(user,type_users)
                return {
                    'message':'Successfully Login',
                    'status':'success',
                    'user': user.to_dict(),
                    'accessToken': token,
                    'data': {
                    'email':user['email'],
                    'name':user['name'],
                    "phone_number" : user['phone_number'],
                    'partner_id':partner_id,
                    'user_id':user['id'],
                    'driver_id' : user_id
                    }   
                }
    #----------------------------------------------------
            if request.env['res.users'].sudo().search([('login', '=', email)]):
                return jwt_request.response(status=400, data={'message': 'Email address is already exist','status': 'failure'})
            #resuser creation
            user = request.env['res.users'].sudo().create({
                'login': email,
                'password': 123,
                'name': name,
                'phone_number':phone_number,
                'email': email,
                'type_users':'driver' 
            })
            #get user id 
        
            user = request.env['res.users'].sudo().search([('phone_number', '=', phone_number)])
            partner = request.env['res.users'].sudo().search_read([('id','=',user.id)],fields=['partner_id'])
            partner_id = partner[0]['partner_id'][0]
            #user master creation 
            
            data_users = {
                'name':name,
                'email':email,
                'mobile':phone_number,
                'password':123,
                'user_type':'driver',
                'driver_user_id':user.id,
                'partner_id':partner_id,
                'longitude':longitude,
                'latitude':latitude,
                'res_city':city,
                'aadhar_no':aadhar,
                'pan_no':pan,
                'referral_code':referral_code,
                'company_name':company_name,
                "gender" : gender,
                "pinky_ponnu" : pinky_ponnu
                
                    }
            user_create = request.env['vb.driver.master'].sudo().create(data_users)
            
            user_id=user_create.id
            
            data2 = [(0,0,{
                "name" : "Driver License",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                     (0,0,{
                "name" : "Driver License Back",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                     (0,0,{
                "name" : "Vehicle Number Plate",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),(0,0,{
                "name" : "Insurance",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),(0,0,{
                "name" : "Profile Photo With Vehicle",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),(0,0,{
                "name" : "RC Book Front",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "RC Book Back",
                "vehicle_ride_type" : "ride",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Driver License",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Driver License Back",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Vehicle Number Plate",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Insurance",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "Profile Photo With Vehicle",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "RC Book Front",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create}),
                (0,0,{
                "name" : "RC Book Back",
                "vehicle_ride_type" : "cargo",
                "driver_id" : user_create})]
            user_create.attchment_ids = data2

            
            
        
            # notification creation
            notification = request.env['notification.list'].sudo().create({
            'name' : 'User Successfully Created!!!',
            'status_id' : 'user_registration',
            'read_status' : 'un_read',
            'res_partner_id' : user.partner_id.id,
            'res_users' : user.id,
            'driver_id':user_create.id,
            'description' : f"Welcome, <b>{name}</b>! 🚗 Start earning with Rate Pesu. Accept ride requests, drive safely, and make money on the go!",
            
            'date' : datetime.datetime.now().date()
                    })
            
            
            if request.env['res.users'].sudo().search([('phone_number', '=', phone_number)]):
                #update mobile number in res partner
                partner = request.env['res.partner'].sudo().browse(int(partner_id)).write({'mobile':phone_number})
                # create token
                token = jwt_request.create_token(user,type_users)
                return {
                    'message':'Successfully Login',
                     'status':'success',
                    'user': user.to_dict(),
                    'accessToken': token,
                    'data': {
                    'email':user['email'],
                    'name':user['name'],
                    'partner_id':partner_id,
                    'user_id':user['id'],
                    'driver_id' : user_id
                    }
                    
                }
        except Exception as e:
            _logger.error(str(e))
            return jwt_request.response_500({
                'message': 'Server error'
            })

    @http.route('/api/driver_attachments',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def driver_attachment(self):
        name = request.params.get("name")
        attachment = request.params.get("attachment")
        driver_id = request.params.get("driver_id")
        cargo_ride_type = request.params.get("cargo_ride_type")
        
        ir_values = {
                'name': str(name),
                'type': 'binary',
                'datas': attachment,
                'mimetype': 'image/png',
                'public': True,
            }
        data_id = request.env['ir.attachment'].sudo().create(ir_values)
        search_orm = request.env['driver.attachment'].sudo().search([('driver_id','=',int(driver_id)),('name','=',str(name)),('vehicle_ride_type','=',str(cargo_ride_type))])
        # search_orm.write({'attachment_id':[(6,0,[data_id.id])],'attachment_success' : True,"vehicle_ride_type" : str(cargo_ride_type)})
        search_orm.sudo().write({'attachment_id':[(6,0,[data_id.id])],'attachment_success' : True})
        search_orm_driver = request.env['vb.driver.master'].sudo().search([('id','=',int(driver_id))])
        driving_license_search_orm = request.env['driver.attachment'].sudo().search([('driver_id','=',int(driver_id)),('vehicle_ride_type','=',str(cargo_ride_type)),('name','=','Driver License')])
        driving_license_back_search_orm = request.env['driver.attachment'].sudo().search([('driver_id','=',int(driver_id)),('vehicle_ride_type','=',str(cargo_ride_type)),('name','=','Driver License Back')])
        number_plate_search_orm = request.env['driver.attachment'].sudo().search([('driver_id','=',int(driver_id)),('vehicle_ride_type','=',str(cargo_ride_type)),('name','=','Vehicle Number Plate')])
        rc_front_search_orm = request.env['driver.attachment'].sudo().search([('driver_id','=',int(driver_id)),('vehicle_ride_type','=',str(cargo_ride_type)),('name','=','RC Book Front')])
        if cargo_ride_type == "ride" and driving_license_search_orm.attachment_success == True and driving_license_back_search_orm.attachment_success == True and number_plate_search_orm.attachment_success == True and rc_front_search_orm.attachment_success == True:
            search_orm_driver.ride_allow = True
        elif cargo_ride_type == "cargo" and driving_license_search_orm.attachment_success == True and driving_license_back_search_orm.attachment_success == True and number_plate_search_orm.attachment_success == True and rc_front_search_orm.attachment_success == True:
            search_orm_driver.cargo_allow = True           
        else:
            pass
        return {
            'message' : "Created Successfully"
        }
                
    @http.route('/api/profile_photo_update',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def profile_photo_update(self):
        driver_id = request.params.get("id")
        image = request.params.get("image")
        user_type = request.params.get('user_type')
        
        if user_type == "driver":
            driver_record = request.env['vb.driver.master'].sudo().search([('id','=',int(driver_id))])
            driver_record.write({'image' : image,'b64_data':image})
            return{
                'message' : "Driver Profile Created Successfully"
            }
        if user_type == "user":
            user_record = request.env['user.master'].sudo().search([('id','=',int(driver_id))])
            user_record.write({'image' : image,'b64_data':image})
            return{
                'message' : "User Profile Created Successfully"
            }
            
    @http.route('/api/attachment',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def attachment_posts(self):
        image = request.params.get("image")
        ir_values = {
            'name': "Attachment Demo",
            'type': 'binary',
            'datas': image,
            'mimetype': 'image/jpeg',
            'public':True
        }
        data_id = request.env['ir.attachment'].sudo().create(ir_values)
        return{
            "id" : data_id.id,
            "message" : "Attachment Created"
        }
        
        
    @http.route('/api/base_fair_cal',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def base_fair_cal(self):
        pick_latitude = request.params.get("pick_latitude")
        pick_longitude = request.params.get("pick_longitude")
        drop_latitude = request.params.get("drop_latitude")
        drop_longitude = request.params.get("drop_longitude")

        
        origin = f"{pick_latitude},{pick_longitude}"
        destination = f"{drop_latitude},{drop_longitude}"
        endpoint = "https://maps.googleapis.com/maps/api/distancematrix/json"
        params = {
        'units': 'metric',  
        'origins': origin,
        'destinations': destination,
        'key': 'AIzaSyCfgilFR2oSr84McNW-Qm1boqGR7wqGtDk',
        'mode' : 'driving',
        }
        response = requests.get(endpoint, params=params).json()
        if response['status'] == 'OK':
            data = response['rows'][0]['elements'][0]
            if data['status'] == 'OK':
                distance = round(data['distance']['value'] / 1000, 2)
                duration = math.ceil(data['duration']['value'] / 60)
                base_fair = request.env['vb.book.master'].sudo().get_base_fair(distance)
                return {'market_fair':{'data':base_fair,'duration':duration}}
            else:
                return {'market_fair':data['status']}
        else:
            return {'market_fair':response['status']}
        
        
    @http.route('/api/message_channel_create', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def message_channel_create(self):

        booking_id=request.params.get('id')
        channel_create = request.env['vb.book.master'].sudo().browse(int(booking_id)).compute_channel_creation(booking_id)  

        
        return {
            'message' :booking_id
            }
    @http.route('/api/otp/auth', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def authentication(self, booking_id=None, otp=None,**kw):

        booking_id = request.params.get('booking_id')
        otp = request.params.get('otp')
        
        auth=request.env['vb.book.master'].sudo().search([('id', '=',booking_id),('otp', '=',otp)])
        if auth:
            auth.booking_status='transit'
            auth.start_time = datetime.datetime.now()
            return{
                    'message': 'OTP Verified And Ride Started',
                    'status': 'success'
                }
        else:
            return {
                    'message': 'Not Valid Otp',
                    'status': 'failure'
                }
            
    @http.route('/api/payment_post',type="json",auth="none",methods=["POST"],cors="*",csrf=False)
    def payment_post(self):
        booking_id = request.params.get('booking_id')
        customer_id = request.params.get('customer_id')
        key = request.params.get('key')
        payment = request.params.get('payment')
        payment_mode = request.params.get('payment_mode')
        
        booking_orm = request.env['vb.book.master'].sudo().search([('id','=',booking_id)])
        if booking_orm.price == payment:
            booking_orm.write({
                'price' : float(payment),
                'payment_status' : "paid",
                'payment_mode' : payment_mode
            })
            request.env["payment.transaction.model"].sudo().create({
                'booking_id' : booking_id,
                'key_id' : key,
                'customer_id' : customer_id,
                "price" : float(payment),
                "status" : "post"
            })
            request.env["notification.list"].sudo().create({
                'name' : f'Payment Post {booking_orm.customer_id.name}',
                'status_id' : "paid",
                'customer_id' : customer_id,
                "description" : f"Payment Paid by the Customer {booking_orm.customer_id.name}",
                "status_id" : "paid",
                "user" : True
            })
            return{
                "status" : "Successfull",
                "message" : "Payment Successfully Created"
            }
        else:
            return{
            "status" : "Unsuccessfull",
            "message" : "Amount Mis-Match"
        }
            
            
#EVENT

    @http.route('/user_master_sequence',type="json",auth="none",methods=["POST"],csrf=False,cors="*")
    def user_master_sequence(self):
        id = request.params.get('id')
        user_master_orm = request.env['user.master'].sudo().search([('id','=',id)])
        user_master_orm.user_sequence()

    
    @http.route('/driver_master_sequence',type="json",auth="none",methods=["POST"],csrf=False,cors="*")
    def driver_master_sequence(self):
        id = request.params.get('id')
        driver_master_orm = request.env['vb.driver.master'].sudo().search([('id','=',id)])
        driver_master_orm.driver_sequence()
        
    @http.route('/cargo_sequence',type="json",auth="none",methods=["POST"],csrf=False,cors="*")
    def cargo_sequence(self):
        id = request.params.get('id')
        booking= request.env['cargo.booking'].sudo().search([('id','=',id)])
        booking.cargo_sequence()    
        
    @http.route('/booking_sequence',type="json",auth="none",methods=["POST"],csrf=False,cors="*")
    def booking_sequence(self):
        id = request.params.get('id')
        booking= request.env['vb.book.master'].sudo().search([('id','=',id)])
        booking.booking_sequence()    
        
    @http.route('/vehicle_sequence_number',type="json",auth="none",methods=["POST"],csrf=False,cors="*")
    def vehicle_sequence_number(self):
        id = request.params.get('id')
        vehicle_master_orm = request.env['vehicle.master'].sudo().search([('id','=',id)])
        vehicle_master_orm.vehicle_sequence()
        return{
            "message" : vehicle_master_orm.seq_no
        }

#ACTION

    @http.route('/coupon_apply',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def coupon_apply_booking(self):
        booking_id = request.params.get('booking_id')
        coupon = request.params.get('coupon')
        
        coupon_orm = request.env['coupon.program'].sudo().search([('promo_code','=',coupon)])
        if coupon_orm:
            booking_orm = request.env['vb.book.master'].sudo().search([('id','=',booking_id)])
            if coupon_orm.rule_minimum_amount:
                coupon_amount = coupon_orm.rule_minimum_amount
            else:
                pass
            booking_orm.write({
                'price' : booking_orm.fair_price - coupon_amount,
                'coupon_applied_price' : coupon_amount,
                'promotion_id' : coupon_orm.id
                })
            return{
                "status" : "Success",
                "message" : "Coupon Applied Successfully"
            }
        else:
            return{
                "status" : "Failure",
                "message" : "Token not match for this Customer"
            }

    @http.route('/coupon_remove',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def coupon_remove_booking(self):
        booking_id = request.params.get('booking_id')
        
        booking_orm = request.env['vb.book.master'].sudo().search([('id','=',int(booking_id))])
        if booking_orm:
            coupon_amount = booking_orm.promotion_id.rule_minimum_amount
            booking_orm.write({
                'price' : booking_orm.fair_price,
                'coupon_applied_price' : False,
                'promotion_id' : False
                })
            return{
                "status" : "Success",
                "message" : "Coupon Removed Successfully"
            }
        else:
            return{
                "status" : "Failure",
                "message" : "Token not match for this Customer"
            }

    @http.route('/api/book_conform', type='json', auth='public', csrf=False, cors='', methods=['POST'])
    def book_conform(self): 
        driver_transaction_id = request.params.get('id')
        booking = request.env['vb.driver.transaction'].sudo().search_read([('id','=',driver_transaction_id)],fields=['booking_id'])
        if booking:
            booking_id=(int(booking[0]['booking_id'][0]))
            request.env['vb.driver.transaction'].sudo().browse(driver_transaction_id).conform_book()
            request.env['vb.book.master'].sudo().browse(int(booking_id)).write({'otp':random.randint(1000, 9999)})       
            self.book_conform_notify(booking_id) 
            self.book_conform_notify_push(booking_id) 
                
            return {'message':booking}
        else:
            return {'message':'booking not found'}  
        
        
    def book_conform_notify(self,booking_id=None):
        booking = request.env['vb.book.master'].sudo().search([('id','=',booking_id)])
        if booking.driver_id :
            driver_data={           
                    'name':f"Your booking has confirmed.",
                    'manager':True,
                    'driver_id':booking.driver_id.id,
                    'date':datetime.datetime.now().date(),
                    'status_id':'booked',
                    'booking_id':booking.id,
                    'description':f"Your booking has confirmed and Your Reference is {booking.booking_seq}"
                    }
            request.env['notification.list'].sudo().create(driver_data)
        if booking.customer_id :
            customer_data={           
                    'name':f"Your booking has confirmed.",
                    'user':True,
                    'customer_id':booking.customer_id.id,
                    'date':datetime.datetime.now().date(),
                    'status_id':'booked',
                    'booking_id':booking.id,
                    'description':f"Your booking has confirmed and Your Reference is {booking.booking_seq}"
                    }
            request.env['notification.list'].sudo().create(customer_data)
            
    def book_conform_notify_push(self,booking_id=None):
        booking = request.env['vb.book.master'].sudo().search([('id','=',booking_id)])        
        otp=booking.otp
        one_signal_data = request.env['one.signal.master'].sudo().search_read([('passenger_id','=',int(booking.customer_id.id))],fields=['key','signal_type'])  
        for j in one_signal_data:
            doc_key_idss = j['key']
            signal_val = j['signal_type']

            if signal_val=='android':
                url = "https://onesignal.com/api/v1/notifications"

                payload = {
                        "include_player_ids":[doc_key_idss],
                        "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                        "contents": {"en": f"Your booking is confirmed, and the One Time Password (OTP) is {otp}"},
                        "headings": {"en": "Semja"},
                        # "buttons": [{"id": "header_color_button", "text": "Semja", "color": "#FF0000"}],
                        "data": {"foo": "bar"},
                        "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                        "name": "INTERNAL_CAMPAIGN_NAME"
                        }

                headers = {
                        "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                        'Content-Type': 'application/json; charset=utf-8',
                    }

                response = requests.post(url, json=payload, headers=headers)

                return {'message':response.text}        
        
                  
    @http.route('/api/credit/wallet', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def credit_wallet(self, wallet_id=None, credit_price=None,**kw):

        wallet_id=request.params.get('wallet_id')
        credit_price=request.params.get('credit_price')

        credit_transaction=[(0,0,{
                    'mode':'credit',
                    'credit_price':float(credit_price),
        })]
        wallet=request.env['wallet.wallet'].sudo().search([('id', '=',wallet_id)])
        wallet.booking_wallet_line=credit_transaction
        if wallet.driver_id :
            driver_data={           
                    'name':f"Wallet",
                    'manager':True,
                    'driver_id':wallet.driver_id.id,
                    'date':datetime.datetime.now().date(),
                    'description':f"Hi {wallet.driver_id.name}, {credit_price} INR Credited In Your Wallet Successfully"
                    }
            request.env['notification.list'].sudo().create(driver_data)
            one_signal_data = request.env['one.signal.master'].sudo().search_read([('driver_id','=',int(wallet.driver_id.id))],fields=['key','signal_type'])  
            for j in one_signal_data:
                doc_key_idss = j['key']
                signal_val = j['signal_type']

                if signal_val=='android':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                            "contents": {"en": f"Hi {wallet.driver_id.name}, {credit_price} INR Credited In Your Wallet Successfully"},
                            "headings": {"en": "Wallet"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                            'Content-Type': 'application/json; charset=utf-8',
                        }
                    
                    response = requests.post(url, json=payload, headers=headers)

            return {
                        'message': f"{credit_price} added to your Wallet Sucessfully",
                        'status':"Success"
                    }
        else:
            return {
                        'status':"Failure"
                    }
    

    @http.route('/api/cargo_base_fare',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def cargo_base_fare(self):
        pick_latitude = request.params.get("pick_latitude")
        pick_longitude = request.params.get("pick_longitude")
        drop_latitude = request.params.get("drop_latitude")
        drop_longitude = request.params.get("drop_longitude")
        category_id = request.params.get("category_id")
        
        origin = f"{pick_latitude},{pick_longitude}"
        destination = f"{drop_latitude},{drop_longitude}"
        endpoint = "https://maps.googleapis.com/maps/api/distancematrix/json"
        params = {
        'units': 'metric',
        'origins': origin,
        'destinations': destination,
        'key': 'AIzaSyCfgilFR2oSr84McNW-Qm1boqGR7wqGtDk',
        'mode' : 'driving',
        }
        response = requests.get(endpoint, params=params).json()
        if response['status'] == 'OK':
            data = response['rows'][0]['elements'][0]
            if data['status'] == 'OK':
                distance = round(data['distance']['value'] / 1000, 2)
                base_fair = request.env['cargo.booking'].sudo().cargo_base_price(distance,category_id)
                return {'market_fair':{'data':base_fair}}
            else:
                return {'market_fair':{"data":data['status'],'status':False}}
        else:
            return {'market_fair':{"data":response['status'],'status':False}} 



    @http.route('/api/driver_arraived_notify',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def driver_arraived_notify(self):
        booking_id = request.params.get("booking_id")
        
        booking = request.env['vb.book.master'].sudo().search([('id','=',booking_id)])
        if booking.booking_status == "reached":
            one_signal_data = request.env['one.signal.master'].sudo().search_read([('passenger_id','=',int(booking.customer_id.id))],fields=['key','signal_type'])  
            
            for j in one_signal_data:
                doc_key_idss = j['key']
                signal_val = j['signal_type']

                if signal_val=='android':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                            "contents": {"en": f"Your driver has arrived, and the OTP is {booking.otp}"},
                            "headings": {"en": "Driver Arrived"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                            'Content-Type': 'application/json; charset=utf-8',
                        }
                    response = requests.post(url, json=payload, headers=headers)
        
                    return{
                            "status" : "Successfull",
                            "message" :"Notification Created Successfully",
                            "response":response.text
                        } 
                else:
                    return{
                        "status" : "Un Successfull",   
                    }                 
            else:
                return {'message': 'failed'}
        
    @http.route('/api/cancel_booking', type='json', auth='public', csrf=False, cors='', methods=['POST'])
    def cancel_booking(self): 

        booking_id = request.params.get('id')
        booking = request.env['vb.book.master'].sudo().search([('id', '=',booking_id)])
        
        if booking.booking_status=='cancel' and booking.driver_id and booking.cancel_by=='passenger' :
            driver_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your Ride has been cancelled by Customer",
            'manager':True,
            'driver_id':booking.driver_id.id,
            'date':datetime.datetime.now(),
            'status_id':'cancel',
            'booking_id':booking.id,
            'description':f"Your Ride has been canceled due to the {booking.cancelled_reason.booking_cancel_reason} by Customer"

        })
            one_signal_data = request.env['one.signal.master'].sudo().search_read([('driver_id','=',int(booking.driver_id.id))],fields=['key','signal_type'])  
            for j in one_signal_data:
                doc_key_idss = j['key']
                signal_val = j['signal_type']

                if signal_val=='android':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                            "contents": {"en": f"Your Ride has been canceled due to the {booking.cancelled_reason.booking_cancel_reason}"},
                            "headings": {"en": "Semja"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                            'Content-Type': 'application/json; charset=utf-8',
                        }

                    response = requests.post(url, json=payload, headers=headers)

                    return{
                        "status" : "Successfull",
                        "message" : "Notification Created Successfully",
                        "response":response.text
                        } 
                else:
                    return{
                        "status" : "Un Successfull",
                        
                    }    
    
        if booking.booking_status=='cancel' and booking.customer_id and booking.cancel_by=='driver' :
            customer_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your Ride has been canceled by Driver",
            'user':True,
            'customer_id':booking.customer_id.id,
            'date':datetime.datetime.now(),
            'status_id':'cancel',
            'booking_id':booking.id,
            'description':f"Your Ride has been canceled due to the {booking.cancelled_reason.booking_cancel_reason} by Driver"
        })
            one_signal_data = request.env['one.signal.master'].sudo().search_read([('passenger_id','=',int(booking.customer_id.id))],fields=['key','signal_type'])  
            for j in one_signal_data:
                doc_key_idss = j['key']
                signal_val = j['signal_type']

                if signal_val=='android':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                            "contents": {"en": f"Your Ride has been canceled due to the {booking.cancelled_reason.booking_cancel_reason} by Driver"},
                            "headings": {"en": "Semja"},
                            "buttons": [{"id": "header_color_button", "text": "Semja", "color": "#FF0000"}],
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                            'Content-Type': 'application/json; charset=utf-8',
                        }

                    response = requests.post(url, json=payload, headers=headers)
        
                    return{
                            "status" : "Successfull",
                            "message" : "Notification Created Successfully",
                            "response":response.text
                    } 
                else:
                    return{
                        "status" : "Un Successfull",   
                    }         
                
                
            
    @http.route('/api/driver_rating', type='json', auth='public', csrf=False, cors='', methods=['POST'])
    def driver_rating(self): 
        driver_id = request.params.get('driver_id') 
        
        request.env['driver.rating.lines'].sudo().browse(driver_id)._compute_overall_rating()
        
        return {"message" : "success"}
    
    @http.route('/api/membership_update',type="json",auth="none",cors="*",csrf=False,methods=["POST"])
    def membership_update(self):
        driver_id = request.params.get("driver_id")
        membership_id = request.params.get("membership_id")

        membership_orm = request.env['membership.table'].sudo().search([('id','=',membership_id)])
        driver_orm = request.env['vb.driver.master'].sudo().search([('id','=',driver_id)])
        driver_orm.write({
            'driver_membership_id' : membership_orm.id,
            'validity' : membership_orm.validity,
            'total_ride' :membership_orm.total_ride ,
            'prime' : True
        })
        data = {
                'name' : f"MemberShip for Driver {driver_orm.name}",
                'read_status' : "un_read",
                'date' : date.today(),
                'res_partner_id' : driver_orm.partner_id.id,
                'res_users' : driver_orm.driver_user_id.id,
                'manager' : True,
                'driver_id' : driver_orm.id,
                'description' : f"Hello {driver_orm.name}, your membership has been created successfully!"
                }
        create_notification = request.env['notification.list'].sudo().create(data)
        one_signal_data = request.env['one.signal.master'].sudo().search_read([('driver_id','=',int(driver_orm.id))],fields=['key','signal_type'])
        for j in one_signal_data:
            doc_key_idss = j['key']
            signal_val = j['signal_type']

            if signal_val=='android':
                url = "https://onesignal.com/api/v1/notifications"

                payload = {
                        "include_player_ids":[doc_key_idss],
                        "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                        "contents": {"en": f"Hello {driver_orm.name}, your membership has been created successfully!"},
                        "headings": {"en": "Membership"},
                        "data": {"foo": "bar"},
                        "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                        "name": "INTERNAL_CAMPAIGN_NAME"
                        }

                headers = {
                        "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                        'Content-Type': 'application/json; charset=utf-8',
                    }
                
                response = requests.post(url, json=payload, headers=headers)
        
        return{
            "status" : "Successfull",
            "message" : "Successfully Updated",
        } 
        
    
    @http.route('/helpdesk_sequence',type="json",auth="none",methods=["POST"],csrf=False,cors="*")
    def helpdesk_sequence(self):
        id = request.params.get('id')
        sequence = request.env['helpdesk.ticket'].sudo().search([('id','=',id)])
        sequence.helpdesk_sequence()
      
    @http.route('/api/helpdesk_channel_create', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def helpdesk_channel_create(self):

        ticket_id=request.params.get('id')
        channel_create = request.env['helpdesk.ticket'].sudo().browse(int(ticket_id)).helpdesk_channel_creation(ticket_id)  

        
        return {
            'message' :ticket_id,

            }  

    @http.route('/api/vehicle_image_update',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def vehicle_image_update(self):
        id = request.params.get("id")
        image = request.params.get("image")
        vehicle_record = request.env['vehicle.master'].sudo().search([('owner.id','=',int(id))])
        vehicle_record.write({'profile' : image})
        return{
                'status' : "Success",
                'message' : "Vehicle Image Updated Successfully"
            }
        
    @http.route('/api/done_booking', type='json', auth='public', csrf=False, cors='', methods=['POST'])
    def done_booking(self): 

        booking_id = request.params.get('id')
        booking = request.env['vb.book.master'].sudo().search([('id', '=',booking_id)])
    
        if  booking.payment_status=="paid" and booking.booking_status=='done' and booking.driver_id and booking.price and booking.customer_id:
            wallet=request.env['wallet.wallet'].sudo().search([('driver_id', '=', int(booking.driver_id.id))],limit=1)
            if wallet:
                debit_transaction=[(0,0,{
                    'mode':'debit',
                    'booking_id':int(booking_id),
                    'deduction_percentage':float(5),
                    'charity_price':float(0),
                })]
                wallet.booking_wallet_line=debit_transaction
                self.wallet_debit_notification(booking) 
                self.invoice_generation(booking)
                self.driver_notification(booking)  
                self.customer_notification(booking)
               
                return {
                    'message' :"Amount Debited successfully",

                    }   
            else:
                return {
                    'message' :"failure",

                    }
    
    def wallet_debit_notification(self,booking=None):
        wallet_line=request.env['wallet.transaction.line'].sudo().search([('driver_id', '=', int(booking.driver_id.id)),('booking_id', '=', int(booking.id))],limit=1)
        if wallet_line.debit_price:
            driver_notification = request.env["notification.list"].sudo().create({
                'name' :"Wallet Debit",
                'manager':True,
                'driver_id':booking.driver_id.id,
                'date':datetime.datetime.now(),
                'status_id':'paid',
                'booking_id':booking.id,
                'description':f"{wallet_line.debit_price} INR has been debited from your wallet"
            })
            one_signal_data = request.env['one.signal.master'].sudo().search_read([('driver_id','=',int(booking.driver_id.id))],fields=['key','signal_type'])
            for j in one_signal_data:
                doc_key_idss = j['key']
                signal_val = j['signal_type']

                if signal_val=='android':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                            "contents": {"en": f"{wallet_line.debit_price} INR has been debited from your wallet"},
                            "headings": {"en": "Wallet Debit"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                            'Content-Type': 'application/json; charset=utf-8',
                        }
                    
                    response = requests.post(url, json=payload, headers=headers)

                    return{
                        "status" : "Successfull",
                        "message" : "Notification Created Successfully",
                        "response":response.text
                    } 
                else:
                    return{
                        "status" : "Un Successfull",  
                    }             
    
    def invoice_generation(self,booking=None):
        booking = request.env['vb.book.master'].sudo().search([('id', '=',int(booking))])
        if  booking.payment_status=="paid" and booking.booking_status=='done' and booking.driver_id and booking.price and booking.customer_id:
            invoice=request.env['account.move'].sudo().create([{
                'partner_id': booking.customer_id.partner_id.id ,
                'move_type': 'out_invoice',
                'l10n_in_gst_treatment':'consumer',
                # 'journal_id':1,
                'invoice_date': datetime.datetime.now(),
                'invoice_date_due': datetime.datetime.now(),
                'booking_id': booking.id,
                'invoice_line_ids':[
                    (0, 0, {
                        'booking_id': booking.id,
                        'product_id': 1,
                        'name': str(booking.booking_seq),
                        'price_unit': booking.price,
                        'quantity':1, 
                    }),
                ],
                }])
            invoice.action_post()
            invoice.payment_state='paid'
            if invoice:
                payment = request.env['account.payment'].sudo().create([{
                    'payment_type': 'inbound',
                    'partner_type': 'customer',
                    'partner_id':booking.customer_id.partner_id.id ,
                    'amount': booking.price,
                    'ref':invoice.name,
                    }])
                if payment:
                    payment.action_post()        
                    
    def driver_notification(self,booking=None):
        driver_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your Ride Was Done Successfully & Thank You! by Semja",
            'manager':True,
            'driver_id':booking.driver_id.id,
            'date':datetime.datetime.now(),
            'status_id':'paid',
            'booking_id':booking.id,
            'description':f"Your ride was completed successfully. Thank you for choosing Semja!"

        })
        one_signal_data = request.env['one.signal.master'].sudo().search_read([('driver_id','=',int(booking.driver_id.id))],fields=['key','signal_type'])  
        for j in one_signal_data:
            doc_key_idss = j['key']
            signal_val = j['signal_type']

            if signal_val=='android':
                url = "https://onesignal.com/api/v1/notifications"

                payload = {
                        "include_player_ids":[doc_key_idss],
                        "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                        "contents": {"en": f"Your ride was completed successfully. Thank you for choosing Semja!"},
                        "headings": {"en": "Semja"},
                        "data": {"foo": "bar"},
                        "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                        "name": "INTERNAL_CAMPAIGN_NAME"
                        }

                headers = {
                        "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                        'Content-Type': 'application/json; charset=utf-8',
                    }
                
                response = requests.post(url, json=payload, headers=headers)

                return{
                    "status" : "Successfull",
                    "message" : "Notification Created Successfully",
                    "response":response.text
                } 
            else:
                return{
                    "status" : "Un Successfull",  
                }    
    
    def customer_notification(self,booking=None):
        customer_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your Ride Was Done Successfully & Thank You! by Semja",
            'user':True,
            'customer_id':booking.customer_id.id,
            'date':datetime.datetime.now(),
            'status_id':'paid',
            'booking_id':booking.id,
            'description':f"Your ride was completed successfully. Thank you for choosing Semja!"
    })
        one_signal_data = request.env['one.signal.master'].sudo().search_read([('passenger_id','=',int(booking.customer_id.id))],fields=['key','signal_type'])  
        for j in one_signal_data:
            doc_key_idss = j['key']
            signal_val = j['signal_type']

            if signal_val=='android':
                url = "https://onesignal.com/api/v1/notifications"

                payload = {
                        "include_player_ids":[doc_key_idss],
                        "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                        "contents": {"en": f"Your ride was completed successfully. Thank you for choosing Semja!"},
                        "headings": {"en": "Semja"},
                        "data": {"foo": "bar"},
                        "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                        "name": "INTERNAL_CAMPAIGN_NAME"
                        }

                headers = {
                        "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                        'Content-Type': 'application/json; charset=utf-8',
                    }
                response = requests.post(url, json=payload, headers=headers)
    
                return{
                        "status" : "Successfull",
                        "message" :"Notification Created Successfully",
                        "response":response.text
                    } 
            else:
                return{
                    "status" : "Un Successfull",   
                }                    
                  

    @http.route('/api/outstation_base_fare',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def outstation_base_fare(self):
        pick_latitude = request.params.get("pick_latitude")
        pick_longitude = request.params.get("pick_longitude")
        drop_latitude = request.params.get("drop_latitude")
        drop_longitude = request.params.get("drop_longitude")
        trip_type = request.params.get("trip_type")
        days = math.ceil(request.params.get("hours")/24)

        origin = f"{pick_latitude},{pick_longitude}"
        destination = f"{drop_latitude},{drop_longitude}"
        endpoint = "https://maps.googleapis.com/maps/api/distancematrix/json"
        params = {
        'units': 'metric',
        'origins': origin,
        'destinations': destination,
        'key': 'AIzaSyCfgilFR2oSr84McNW-Qm1boqGR7wqGtDk',
        'mode' : 'driving',
        }
        response = requests.get(endpoint, params=params).json()
        if response['status'] == 'OK':
            data = response['rows'][0]['elements'][0]
            if data['status'] == 'OK':
                distance = round(data['distance']['value'] * 2/ 1000, 2) 
                base_fair = request.env['vb.book.master'].sudo()._outstation_base_price(distance,days)                
                return {'market_fair':{'data':base_fair}}
            else:
                return {'market_fair':data['status']}
        else:
            return {'market_fair':response['status']}                    
        
    @http.route('/coupon_valid',type="json",auth="none",methods=["POST"],csrf=False,cors='*')
    def coupon_valid(self):
        coupon_id = request.params.get('coupon_id')
        customer_id=request.params.get('customer_id')
        
        valid_coupon = request.env['vb.book.master'].sudo().search([('coupon_id','=',int(coupon_id)),('customer_id','=',int(customer_id))])
        if valid_coupon: 
            return{
                "status" : "Faliure",
                "message" : "Coupon has been used already"
            }
        
        else:
            return{
                "status" : "Success",
                "message" : "Coupon has not been used"
            }
            
    @http.route('/api/cargo_book_conform', type='json', auth='public', csrf=False, cors='', methods=['POST'])
    def cargo_book_conform(self): 
        driver_transaction_id = request.params.get('id')
        booking = request.env['cargo.bidding.price'].sudo().search_read([('id','=',driver_transaction_id)],fields=['cargo_booking_id'])
        if booking:
            booking_id=(int(booking[0]['cargo_booking_id'][0]))
            request.env['cargo.bidding.price'].sudo().browse(driver_transaction_id).conform_book()
            request.env['cargo.booking'].sudo().browse(int(booking_id)).write({'otp':random.randint(1000, 9999)}) 
            self.cargo_book_conform_notify(booking_id)
            self.cargo_book_conform_notify_push(booking_id)

            return {'message':booking_id}
        else:
            return {'message':'booking not found'}  
        
    def cargo_book_conform_notify(self,booking_id=None):
        booking = request.env['cargo.booking'].sudo().search([('id','=',booking_id)])
        if booking.driver_id :
            driver_data={           
                    'name':f"Your booking has confirmed.",
                    'manager':True,
                    'driver_id':booking.driver_id.id,
                    'date':datetime.datetime.now().date(),
                    'status_id':'booked',
                    'cargo_booking_id':booking.id,
                    'description':f"Your booking has confirmed and Your Reference is {booking.cargo_seq}"
                    }
            request.env['notification.list'].sudo().create(driver_data)
        if booking.passenger_id :
            customer_data={           
                    'name':f"Your booking has confirmed.",
                    'user':True,
                    'customer_id':booking.passenger_id.id,
                    'date':datetime.datetime.now().date(),
                    'status_id':'booked',
                    'cargo_booking_id':booking.id,
                    'description':f"Your booking has confirmed and Your Reference is {booking.cargo_seq}"
                    }
            request.env['notification.list'].sudo().create(customer_data)
            
    def cargo_book_conform_notify_push(self,booking_id=None):
        booking = request.env['cargo.booking'].sudo().search([('id','=',booking_id)])        
        otp=booking.otp
        one_signal_data = request.env['one.signal.master'].sudo().search_read([('passenger_id','=',int(booking.passenger_id.id))],fields=['key','signal_type'])  
        for j in one_signal_data:
            doc_key_idss = j['key']
            signal_val = j['signal_type']

            if signal_val=='android':
                url = "https://onesignal.com/api/v1/notifications"

                payload = {
                        "include_player_ids":[doc_key_idss],
                        "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                        "contents": {"en": f"Your booking is confirmed, and the One Time Password (OTP) is {otp}"},
                        "headings": {"en": "Semja"},
                        "data": {"foo": "bar"},
                        "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                        "name": "INTERNAL_CAMPAIGN_NAME"
                        }

                headers = {
                        "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                        'Content-Type': 'application/json; charset=utf-8',
                    }

                response = requests.post(url, json=payload, headers=headers)

                return {'message':response.text}          
                
    @http.route('/api/cargo_cancel_booking', type='json', auth='public', csrf=False, cors='', methods=['POST'])
    def cargo_cancel_booking(self): 

        cargo_booking_id = request.params.get('id')
        booking = request.env['cargo.booking'].sudo().search([('id', '=',cargo_booking_id)])
        
        if booking.booking_status=='cancel' and booking.driver_id:
            driver_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your booking has been cancelled",
            'manager':True,
            'driver_id':booking.driver_id.id,
            'date':datetime.datetime.now(),
            'status_id':'cancel',
            'cargo_booking_id':booking.id,
            'description':f"Your booking has been canceled due to the {booking.cancelled_reason_id.booking_cancel_reason}"

        })
            one_signal_data = request.env['one.signal.master'].sudo().search_read([('driver_id','=',int(booking.driver_id.id))],fields=['key','signal_type'])  
            for j in one_signal_data:
                doc_key_idss = j['key']
                signal_val = j['signal_type']

                if signal_val=='android':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                            "contents": {"en": f"Your booking has been canceled due to the {booking.cancelled_reason_id.booking_cancel_reason}"},
                            "headings": {"en": "Semja"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                            'Content-Type': 'application/json; charset=utf-8',
                        }

                    response = requests.post(url, json=payload, headers=headers)

                    return{
                        "status" : "Successfull",
                        "message" : "Notification Created Successfully",
                        "response":response.text
                    } 
                    
                else:
                    return{
                        "status" : "Un Successfull",
                        
                    }    
    
        if booking.booking_status=='cancel' and booking.passenger_id:
            customer_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your booking has been canceled",
            'user':True,
            'customer_id':booking.passenger_id.id,
            'date':datetime.datetime.now(),
            'status_id':'cancel',
            'cargo_booking_id':booking.id,
            'description':f"Your booking has been canceled due to the {booking.cancelled_reason_id.booking_cancel_reason}"
        })
            one_signal_data = request.env['one.signal.master'].sudo().search_read([('passenger_id','=',int(booking.passenger_id.id))],fields=['key','signal_type'])  
            for j in one_signal_data:
                doc_key_idss = j['key']
                signal_val = j['signal_type']

                if signal_val=='android':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                            "contents": {"en": f"Your booking has been canceled due to the {booking.cancelled_reason_id.booking_cancel_reason}"},
                            "headings": {"en": "Semja"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                            'Content-Type': 'application/json; charset=utf-8',
                        }

                    response = requests.post(url, json=payload, headers=headers)
        
                    return{
                            "status" : "Successfull",
                            "message" : "Notification Created Successfully",
                            "response":response.text
                    } 
                    
                else:
                    return{
                        "status" : "Un Successfull",   
                    }                     
                
    @http.route('/api/cargo_done_booking', type='json', auth='public', csrf=False, cors='', methods=['POST'])
    def cargo_done_booking(self): 

        cargo_booking_id = request.params.get('id')
        booking = request.env['cargo.booking'].sudo().search([('id', '=',cargo_booking_id)])
    
        if  booking.payment_status=="paid" and booking.booking_status=='done' and booking.driver_id and booking.price and booking.passenger_id:
            self.cargo_invoice_generation(booking)
            self.cargo_driver_notification(booking)  
            self.cargo_customer_notification(booking)
    
    def cargo_invoice_generation(self,booking=None):
        booking = request.env['cargo.booking'].sudo().search([('id', '=',int(booking))])
        if  booking.payment_status=="paid" and booking.booking_status=='done' and booking.driver_id and booking.price and booking.passenger_id:
            invoice=request.env['account.move'].sudo().create([{
                'partner_id': booking.passenger_id.partner_id.id ,
                'move_type': 'out_invoice',
                'l10n_in_gst_treatment':'consumer',
                # 'journal_id':1,
                'invoice_date': datetime.datetime.now(),
                'invoice_date_due': datetime.datetime.now(),
                'cargo_booking_id': booking.id,
                'invoice_line_ids':[
                    (0, 0, {
                        'cargo_booking_id': booking.id,
                        'product_id': 1,
                        'name': str(booking.cargo_seq),
                        'price_unit': booking.price,
                        'quantity':1, 
                    }),
                ],
                }])
            invoice.action_post()
            invoice.payment_state='paid'
            if invoice:
                payment = request.env['account.payment'].sudo().create([{
                    'payment_type': 'inbound',
                    'partner_type': 'customer',
                    'partner_id':booking.passenger_id.partner_id.id ,
                    'amount': booking.price,
                    'ref':invoice.name,
                    }])
                if payment:
                    payment.action_post()          
    def cargo_driver_notification(self,booking=None):
        driver_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your cargo delivery has been completed ",
            'manager':True,
            'driver_id':booking.driver_id.id,
            'date':datetime.datetime.now(),
            'status_id':'paid',
            'cargo_booking_id':booking.id,
            'description':f"Your cargo delivery has been completed successfully & Thank you for choosing Semja!"

        })
        one_signal_data = request.env['one.signal.master'].sudo().search_read([('driver_id','=',int(booking.driver_id.id))],fields=['key','signal_type'])  
        for j in one_signal_data:
            doc_key_idss = j['key']
            signal_val = j['signal_type']

            if signal_val=='android':
                url = "https://onesignal.com/api/v1/notifications"

                payload = {
                        "include_player_ids":[doc_key_idss],
                        "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                        "contents": {"en": f"Your cargo delivery has been completed successfully & Thank you for choosing Semja!"},
                        "headings": {"en": "Semja"},
                        "data": {"foo": "bar"},
                        "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                        "name": "INTERNAL_CAMPAIGN_NAME"
                        }

                headers = {
                        "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                        'Content-Type': 'application/json; charset=utf-8',
                    }
                
                response = requests.post(url, json=payload, headers=headers)

                return{
                    "status" : "Successfull",
                    "message" : "Notification Created Successfully",
                    "response":response.text
                } 
            else:
                return{
                    "status" : "Un Successfull",  
                }    
    
    def cargo_customer_notification(self,booking=None):
        customer_notification = request.env["notification.list"].sudo().create({
            'name' :f"Your cargo delivery has been completed ",
            'user':True,
            'customer_id':booking.passenger_id.id,
            'date':datetime.datetime.now(),
            'status_id':'paid',
            'cargo_booking_id':booking.id,
            'description':f"Your cargo delivery has been completed successfully & Thank you for choosing Semja!"
    })
        one_signal_data = request.env['one.signal.master'].sudo().search_read([('passenger_id','=',int(booking.passenger_id.id))],fields=['key','signal_type'])  
        for j in one_signal_data:
            doc_key_idss = j['key']
            signal_val = j['signal_type']

            if signal_val=='android':
                url = "https://onesignal.com/api/v1/notifications"

                payload = {
                        "include_player_ids":[doc_key_idss],
                        "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                        "contents": {"en": f"Your cargo delivery has been completed successfully & Thank you for choosing Semja!"},
                        "headings": {"en": "Semja"},
                        "data": {"foo": "bar"},
                        "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                        "name": "INTERNAL_CAMPAIGN_NAME"
                        }

                headers = {
                        "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                        'Content-Type': 'application/json; charset=utf-8',
                    }
                response = requests.post(url, json=payload, headers=headers)
    
                return{
                        "status" : "Successfull",
                        "message" :"Notification Created Successfully",
                        "response":response.text
                    } 
            else:
                return{
                    "status" : "Un Successfull",   
                }                    
                
                    
    @http.route('/api/cargo_channel_create', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def cargo_channel_create(self):

        cargo_booking_id=request.params.get('id')
        channel_create = request.env['cargo.booking'].sudo().browse(int(cargo_booking_id)).cargo_channel_creation(cargo_booking_id)  

        
        return {
            
            'message' :channel_create,

            }                  