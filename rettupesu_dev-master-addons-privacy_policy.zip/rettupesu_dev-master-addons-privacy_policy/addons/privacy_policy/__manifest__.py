{
    'name': 'Privacy Policy',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Privacy Policy',
    'depends': ['base','mail','helpdesk'],
    'data': [
            'views/privacy_policy.xml',
            'views/privacy_categories.xml',
            'security/ir.model.access.csv',
          
         
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
