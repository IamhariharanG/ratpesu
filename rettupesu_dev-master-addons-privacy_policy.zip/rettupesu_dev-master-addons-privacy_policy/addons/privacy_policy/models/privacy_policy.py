from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Userprivacypolicy(models.Model):
    _name = 'privacy.policy'
    _rec_name = 'category_id'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Helpdesk Categories" 
   
    sequence_num=fields.Integer(string="Serial No",required=True,track_visibility='onchange')
    user_id = fields.Many2one('res.users', string='User',default=lambda self: self.env.user.id,readonly="1")
    header=fields.Char(string="Header",required=True)
    name = fields.Html(string="Name",required=True,track_visibility='onchange')
    state = fields.Selection([('active', 'Active'),('in_active', 'In Active')],string='Status',required=True,default='active',track_visibility='onchange')
    category_id=fields.Many2one('privacy.categories',string="Category")
    is_active =fields.Boolean(string="Active",default=True,required=True,readonly=True)
    is_user=fields.Boolean(string="Is User")
    is_driver=fields.Boolean(string="Is Driver")

    def active(self):
        for rec in self:
            rec.is_active=True
            rec.state='active'

    def in_active(self):
        for rec in self:
            rec.is_active=False
            rec.state='in_active'        

    
    