from . import privacy_policy
from . import privacy_categories