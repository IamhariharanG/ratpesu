from odoo import fields, models, api
from odoo.exceptions import ValidationError


class HrEmployee(models.Model):
    _inherit = "hr.employee"
    
    employee_id = fields.Boolean(string="Employee")