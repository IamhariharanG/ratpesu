from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Vehicletype(models.Model):
    _name = 'vehicle.type'
    _rec_name='name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Vehicle Type'

    image = fields.Binary(string="Image")                   

    category = fields.Many2one("vehicle.category",string="Category",required=True)
    name=fields.Char(string="Vehicle Type",required=True,track_visibility='onchange')
    booking_type = fields.Selection([('auto','Auto'),('car','AC Ride'),('moto','Moto'),('out','Outstation'),('parcel','Freight')],string="Booking Type")
    seating_capacity = fields.Float(string='Seating Capacity in Nos',track_visibility='onchange')
    load_capacity = fields.Float(string='Load Capacity In Kg',track_visibility='onchange')
    total_vehicles = fields.Integer(string='Total Vehicles',compute='compute_total_vehicles')
    brand =fields.Char(string='Brand/Make',track_visibility='onchange')
    model = fields.Char(string = "Model",track_visibility='onchange')
    passenger_carrier = fields.Selection([('passenger','Passenger'),('carrier','Carrier')],string="Passenger/Carrier")
    want_body_type = fields.Boolean(string='Want Body Type', default=False)
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo')],string="Vehicle Ride Type")
    book_type = fields.Many2one("booking.type",string="Booking Type")
    
    size = fields.Char(string = "Size",track_visibility='onchange')
    weight = fields.Char(string = "Weight",track_visibility='onchange')
    house_hold_details=fields.Char(string="House Hold Details")
    
    

     

    def compute_total_vehicles(self):
        total_vehicles = self.env['vehicle.master'].search([('type_id','=',self.id)])
        self.total_vehicles = len(total_vehicles)

    def total_vehicles_count(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vehicle Master',
            'view_mode': 'tree,form',
            'res_model': 'vehicle.master',
            'domain': [('type_id', '=', self.id)],
            
        }       
       
  
class imagemaster(models.Model):
    _name = 'image.master'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    _description = 'Images'

    name = fields.Char(string = 'Name')
    sequence = fields.Char(string = 'Sequence')
    images = fields.Binary(string = 'Upload Image')


class attachmenttype(models.Model):
    _name = "attachment.type"
    _rec_name = "name"
    _inherit = ['mail.thread', 'mail.activity.mixin',]

    name  = fields.Char(string = 'Attachment Type',required =True,track_visibility='onchange')
    attachment_type=fields.Many2one('attachment.type',string="Attachment Type")
    
class vehicle_model(models.Model):
    _name = 'vehicle.model'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    _description = 'Model'

    name = fields.Char(string = 'Name')
    vehicle_type = fields.Many2one('vehicle.type',string="Vehicle Master")
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo')],string="Vehicle Ride Type")
    category_type=fields.Many2one('vehicle.category',string="Category")

       
    
class Colour_master(models.Model):
    _name = 'colour.master'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    _description = 'Colour'

    name = fields.Char(string = 'Name')
       

class year_module(models.Model):
    _name = "year.module"
    _rec_name = "name"


    name = fields.Char(string = 'Year')
    
class BookingType(models.Model):
    _name = 'booking.type'
    _rec_name = 'booking_type'
    _inherit = ['mail.thread', 'mail.activity.mixin',]


    booking_type = fields.Char(string="Booking Type")
    image = fields.Binary(string="Image")      
    is_model = fields.Boolean(string="Is Model")      
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo'),('outstation','Outstation')],string="Vehicle Ride Type")
    form_type = fields.Integer(string="Form Type")
    description = fields.Html(string="Description")
    
