from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Vehiclemaster(models.Model):
    _name = 'vehicle.master'
    _rec_name='number'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Vehicle'

    FUEL_LIST = [ ('diesel','Diesel'),('gasoline','Gasoline'),('electric','Electric')]
    YES_NO = [('yes','Yes'),('no','No')]
    
    crime_records = fields.Selection(YES_NO,string="Crime Records",track_visibility='onchange')
    @api.onchange('crime_records')
    def crime_state_changes(self):
        if self.crime_records == "yes":
            self.status = 'locked'
        else:
            pass
    booking_type = fields.Many2one('booking.type',string = "Booking Type",track_visibility='onchange')
    profile = fields.Binary('Image')
    seq_no = fields.Char('Sequence No')
    type_id=fields.Many2one('vehicle.type',string="Vehicle Type",track_visibility='onchange')
    name=fields.Char(string="Vehicle  Name",track_visibility='onchange')
    address=fields.Char(string="Address",track_visibility='onchange')
    number=fields.Char(string='Vehicle Number',track_visibility='onchange',required=True)
    distance=fields.Float(string="Km/Driven",track_visibility='onchange')
    location_service=fields.Char(string="Service Location",track_visibility='onchange')
    price=fields.Float(string="Price",track_visibility='onchange')
    weight=fields.Float(string="Weight",track_visibility='onchange')
    description=fields.Char(string="Description",track_visibility='onchange')
    brand =fields.Char(string='Brand/Make',track_visibility='onchange')
    model = fields.Char(string = "Model",track_visibility='onchange')
    vehicle_model_id = fields.Many2one('vehicle.model',string = "Model Name",track_visibility='onchange', domain=[])
    # year_of_manufacture = fields.Selection(YEAR_LIST,string="Year Of Manufacture",track_visibility='onchange')
    color = fields.Char(string = "Colour",track_visibility='onchange')
    colour_id = fields.Many2one('colour.master',string = "Colour",track_visibility='onchange')
    want_body_type = fields.Boolean(string='Want Body Type', default=False)

    fuel_type = fields.Selection(FUEL_LIST,string="Fuel Type",track_visibility='onchange')
    owner = fields.Many2one("vb.driver.master",string='Owner',track_visibility='onchange')
    aquisation_date = fields.Date(string='Acquisition Date',track_visibility='onchange')
    purchase_lease_info = fields.Text(string = 'Purchase/Lease Information',track_visibility='onchange')
    availability = fields.Boolean(string = 'Availability',track_visibility='onchange')
    seating_capacity = fields.Float(string='Seating Capacity in Nos',track_visibility='onchange')
    load_capacity = fields.Float(string='Load Capacity In Kg',track_visibility='onchange')
    attachment_ids = fields.Many2many('ir.attachment',string='Attachment Images',attachment=True)
    transmission_type = fields.Selection([ ('manual','Manual'),('automatic','Automatic')],string='Transmission Type',track_visibility='onchange')
    latitude = fields.Char(string="Latitude")
    longitude = fields.Char(string="Longitude")
    total_booking = fields.Integer(string='Total Bookings',compute='compute_total_bookings')
    load_capacity_invisible = fields.Boolean(string='Capacity Invisible', default=False)
    seat_capacity_invisible = fields.Boolean(string='Capacity Invisible', default=False)
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo')],string="Vehicle Ride Type")
    ride_boolean = fields.Boolean(string="Ride Boolean",default=False)
    cargo_boolean = fields.Boolean(string="Cargo Boolean",default=False)
#image vehicle 
    image=fields.Binary(string="Image",track_visibility='onchange')
#locaton vehicle geo map
    latitude=fields.Char(string="Latitude",track_visibility='onchange')
    longitude=fields.Char(string="Longitude",track_visibility='onchange')
#vehicle status
    status=fields.Selection([("inactive","Inactive"),('active',"Active"),('locked',"Locked"),('on_convo',"On Conversation"),('available',"Available")],default="inactive" ,string="Vehicle status",track_visibility='onchange')
    owner_individual = fields.Selection([("owner","Owner"),("individual","Individual")],string= 'Owner/Individual',track_visibility='onchange')
#owner One2many
    owner_ids = fields.One2many('owner.line','owner_id',ondelete = 'cascade',string='Owner Lines')
    
#RECENT CREATED FIELDS:    
    body_type_id = fields.Many2one('body.type',string="Body Type")
    year = fields.Integer(string="Year")

    def vehicle_sequence(self):
        self.seq_no = f"{'V'}{self.env['ir.sequence'].next_by_code('vehicle.sequence.create')}"


    def compute_total_bookings(self):
        total_bookings = self.env['vb.book.master'].search([('vehicle_id','=',self.id)])
        self.total_booking = len(total_bookings)

    def total_bookings_count(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vehicle Master',
            'view_mode': 'tree,form',
            'res_model': 'vb.book.master',
            'domain': [('vehicle_id', '=', self.id)],
            
        }       
        
    @api.constrains('number')
    def existing_number(self):
        for rec in self:
            if rec.number:
                existing_record = self.search([('number', '=', rec.number),('id', '!=', rec.id)])
                if existing_record:
                    raise ValidationError('Vehicle number must be unique!')
                
        
    def active_button(self):
        self.status = 'active'
    
    def locked_button(self):
        self.status = 'locked'

    def on_conversation_button(self):
        self.status = 'on_convo'

    def available_button(self):
        self.status = 'available'

    @api.onchange('type_id')
    def compute_capacity(self):
        for rec in self:
            if rec.type_id:
                record_id = self.env['vehicle.type'].search([('id','=',self.type_id.id)])
                if record_id:
                    selection_field = record_id.passenger_carrier
                    if selection_field == 'passenger':
                        rec.load_capacity_invisible = True
                        rec.seat_capacity_invisible = False  
                    elif selection_field == 'carrier':
                        rec.seat_capacity_invisible = True
                        rec.load_capacity_invisible = False 
                        rec.seating_capacity = rec.type_id.seating_capacity
                        rec.load_capacity = rec.type_id.load_capacity
                        rec.model = rec.type_id.model
                        rec.brand = rec.type_id.brand
            else:
                pass
        if self.type_id:
            domain = [('vehicle_type.id', '=', self.type_id.id)]
            return {'domain': {'vehicle_model_id': domain}}
        else:
            return {'domain': {'vehicle_model_id': []}}


class owner_line(models.Model):
    _name = "owner.line"
    _rec_name = "name"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    FUEL_LIST = [ ('diesel','Diesel'),('gasoline','Gasoline'),('electric','Electric')]

    name  = fields.Char(string = 'Vehicle  Name',required =True,track_visibility='onchange')
    owner_id=fields.Many2one('vehicle.master',string="Vehicles",ondelet='cascade')
    attachment_ids = fields.Many2many('ir.attachment',string='Attachment Images',attachment=True)
    number=fields.Char(string='Vehicle Number',track_visibility='onchange')
    distance=fields.Float(string="Km/Driven",track_visibility='onchange')
    location_service=fields.Char(string="Service Location",track_visibility='onchange')
    price=fields.Float(string="Price",track_visibility='onchange')
    weight=fields.Float(string="Weight",track_visibility='onchange')
    description=fields.Char(string="Description",track_visibility='onchange')
    brand =fields.Char(string='Brand/Make',track_visibility='onchange')
    model = fields.Char(string = "Model",track_visibility='onchange')
    vehicle_model_id = fields.Many2one('vehicle.model',string = "Model Name",track_visibility='onchange')

    # year_of_manufacture = fields.Selection(YEAR_LIST,string="Year Of Manufacture",track_visibility='onchange')
    color = fields.Char(string = "Colour",track_visibility='onchange')
    colour_id = fields.Many2one('colour.master',string = "Colour",track_visibility='onchange')
    fuel_type = fields.Selection(FUEL_LIST,string="Fuel Type",track_visibility='onchange')
    owner = fields.Char(string='Owner',track_visibility='onchange')
    aquisation_date = fields.Date(string='Acquisition Date',track_visibility='onchange')
    seating_capacity = fields.Float(string='Seating Capacity in Nos',track_visibility='onchange')
    load_capacity = fields.Float(string='Load Capacity In Kg',track_visibility='onchange')
    type_id=fields.Many2one('vehicle.type',string="Vehicle Type",track_visibility='onchange')
    body_type = fields.Selection([('open','Open Type'),('close','Closed Type')],string="Body Type")
    year = fields.Integer(string="Year")
    
    vehicle_model_id = fields.Many2one('vehicle.model',string = "Model Name",track_visibility='onchange')
    body_type_id = fields.Many2one('body.type',string="Body Type")

    @api.onchange('type_id')
    def change_domain(self):
        if self.type_id:
            domain = [('vehicle_type.id', '=', self.type_id.id)]
            return {'domain': {'vehicle_model_id': domain}}
        else:
            return {'domain': {'vehicle_model_id': []}}
        
        
   