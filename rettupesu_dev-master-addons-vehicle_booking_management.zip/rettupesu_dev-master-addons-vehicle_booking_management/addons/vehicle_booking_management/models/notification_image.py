from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class BodyType(models.Model):
    _name = 'notification.list.image'
    _rec_name='name'
    _inherit = ['mail.thread','mail.activity.mixin']
    
    name = fields.Selection([('user_registration','User Registration'),
                                  ('user_login','User Login'),
                                  ('offer_notification','Offer Notification'),
                                  ('booking_pending','Booking Pending'),
                                  ('booking_waiting','waiting for driver'),
                                  ('confirmed','Confirmed'),
                                  ('booked','Booked'),
                                  ('cancel', 'Cancelled'),
                                  ('rescheduling','Rescheduling'),
                                  ('paid','Paid')],string='Status',track_visibility='onchange')
    image = fields.Image(string="Name")