from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import ValidationError

class screenimage(models.Model):
    _name = 'screen.image'
    _rec_name = 'type'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    image=fields.Binary(string="Image")
    type=fields.Selection([('user',"User"),('driver',"Driver")],string="Type",track_visibility='onchange')
    screen_no=fields.Integer(string="Screen No",track_visibility='onchange')