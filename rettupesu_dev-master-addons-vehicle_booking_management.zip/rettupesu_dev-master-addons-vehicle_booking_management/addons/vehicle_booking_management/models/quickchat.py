from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class BodyType(models.Model):
    _name = 'ride.quickchat'
    _rec_name='name'
    _inherit = ['mail.thread','mail.activity.mixin']
    
    USER_TYPE = [('user','User'),('driver','Driver')]
    MESSAGE_TYPE = [('chat','Chat'),('channel','Channel')]
    QUESTION_TYPE = [('registration','Registration'),('document','Document'),('ride_booking','Ride Booking')]
    
    BOOK_TYPE = [('ride','Ride'),('cargo','Cargo'),('out_station','Out Station')]
    name = fields.Char(string="Name",tracking=True)
    user_type = fields.Selection(USER_TYPE,string="Type",tracking=True)
    book_type = fields.Selection(BOOK_TYPE,tracking=True)
    message_type = fields.Selection(MESSAGE_TYPE,tracking=True)
    question = fields.Selection(QUESTION_TYPE,string="Question",tracking=True)
    description = fields.Html(string="Description",track_visibility='onchange')
    