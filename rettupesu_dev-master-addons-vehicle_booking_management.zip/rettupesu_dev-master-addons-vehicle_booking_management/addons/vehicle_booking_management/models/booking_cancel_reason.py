from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import ValidationError

class bookingcancelreason(models.Model):
    _name = 'booking.cancel.reason'
    _rec_name = 'booking_cancel_reason'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    customer_name_ = fields.Many2one('user.master', string= "Customer")
    booking_cancel_reason = fields.Char(string="Cancel Reason",track_visibility='onchange')
    is_user = fields.Boolean(string="User")
    is_driver = fields.Boolean(string="Driver")