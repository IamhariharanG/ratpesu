from odoo import models, fields, api
from datetime import datetime,date
import requests
import json
from odoo.exceptions import ValidationError
import math
from geopy.geocoders import Nominatim

class vehicleusermaster(models.Model):
    _name = 'user.master'
    _rec_name = 'name'
    _order = "id asc"
    _inherit = ['mail.thread', 'mail.activity.mixin',]

    status = fields.Selection([('inactive','In-Active'),('active','Active')],default="active",string="Status")
    b64_data = fields.Char(string="Base 64 Data")
    sos_info = fields.One2many('sos.master','user_master_id',string="SOS Contact",ondelete="cascade")
    

    def active_user(self):
        self.status = "active"
    def inactive_user(self):
        self.status = "inactive"
        
    user_seq=fields.Char(string=" User sequence")
    
    def user_sequence(self):
        self.user_seq = f"{'CRP'}{self.env['ir.sequence'].next_by_code('user.sequence.create')}"
    
    total_booking = fields.Integer(string='Total Bookings',compute='compute_total_bookings')

    count_notification_id = fields.Integer(string="Count Notification",compute="count_customer_notification")
    
    def count_customer_notification(self):
        for rec in self:
            self.count_notification_id = self.env["notification.list"].search_count([('customer_id','=',rec.id)])
    
    def count_notification_alert(self):
        return{
            "name" : "Alert Messages",
            "type" : "ir.actions.act_window",
            'view_mode' : "tree,form",
            "res_model" : "notification.list",
            "context" : {
                "default_customer_id" : self.id,
            },
            "domain" : [('customer_id','=',self.id)]
        }
        
    def compute_total_bookings(self):
        total_bookings = self.env['vb.book.master'].search([('customer_id','=',self.id)])
        self.total_booking = len(total_bookings)

    def total_bookings_count(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Booking',
            'view_mode': 'tree,form',
            'res_model': 'vb.book.master',
            'domain': [('customer_id', '=', self.id)],
            
        }   
    
    name  = fields.Char(string = 'Name',required =True,track_visibility='onchange')
    age = fields.Float(string="Age",track_visibility='onchange')
    dob= fields.Date(string="DOB",track_visibility='onchange')
    gender = fields.Selection([('male',"Male"),('female',"Female"),('others',"Others")], string="Gender",track_visibility='onchange')
    phone = fields.Char('Phone',track_visibility='onchange')
    mobile = fields.Char('Mobile',track_visibility='onchange',required= True)
    email = fields.Char('Email',track_visibility='onchange',required= True)
    street_1 = fields.Char('Street1',track_visibility='onchange')
    street_2 = fields.Char('Street2',track_visibility='onchange')
    city = fields.Char('City',track_visibility='onchange')
    res_city = fields.Many2one('res.city',track_visibility='onchange')
    zip_code = fields.Char('Zip',track_visibility='onchange')
    state_id = fields.Many2one('res.country.state', string='State',track_visibility='onchange')
    country_id = fields.Many2one('res.country', string='Country',track_visibility='onchange')
    user_id = fields.Many2one('res.users', string= "User Id",track_visibility='onchange')
    partner_id = fields.Many2one('res.partner',string="Partner Id",track_visibility='onchange')
    user_type = fields.Selection([('driver',"Driver"),("user","User"),('admin',"Admin")], string="User Type",track_visibility='onchange',default = 'user',readonly=True)
    driver_status = fields.Selection([('active',"Active"),("inactive","Inactive"),('locked',"Locked"),('on_convo',"On Conversation"),('available',"Available")], string="Driver status",track_visibility='onchange')
    user_status = fields.Selection([('booked',"Booked"),("available","Available")], string="User status",track_visibility='onchange')
    latitude=fields.Char(string="Latitude",track_visibility='onchange')
    longitude=fields.Char(string="Longitude",track_visibility='onchange')
    image=fields.Binary(string="Image",track_visibility='onchange')
    tracking_vehicle_ids = fields.One2many("user.vehicle.tracking","res_id",string="Fetch Vehicles",ondelete="cascade")
    password = fields.Char(string="Password",track_visibility='onchange')
  
    bookmark_count_=fields.Integer(string='Total Bookmarks',compute='compute_bookmark_counts')
    
    booking_history_count=fields.Integer(string="Booking History Count",compute='compute_history_counts')
    
    notification_count = fields.Integer(string="Count",compute="count_notification")
    coupon_count = fields.Integer(string="Count",compute="count_coupon")
    complaint_count = fields.Integer(string="Count",compute="count_complaint")
    
    #referal
    referral_code=fields.Char(string='Referral Code')
    ref_user_id=fields.Many2one('user.master',string='Referred Person',compute='user_referred_person',store=True)
    

    @api.depends('referral_code')
    def user_referred_person(self):
        if self.referral_code:
            user = self.search([('user_seq', '=',self.referral_code)],limit=1)                 
            if user:
                self.ref_user_id=user.id
    
    def count_coupon(self):
        for rec in self:
            rec.coupon_count = self.env['coupon.coupon'].search_count([('partner_id','=',rec.partner_id.id)])
    
    def count_complaint(self):
        for rec in self:
            rec.complaint_count = self.env['helpdesk.ticket'].search_count([('passenger_id','=',rec.id)])
    
    def count_notification(self):
        for rec in self:
            rec.notification_count = self.env['notification.master'].search_count([('user_id','=',rec.id)])
        
    def notification_master(self):
        return{
            "name" : "Notification  List",
            "view_mode" : "tree,form",
            "type" : "ir.actions.act_window",
            "res_model" : "notification.master",
            "domain" : [('user_id.id','=',self.id)],
            "context" : {"default_user_id":self.id},
            
        }
        
    def coupon_coupon(self):
        return{
            "name" : "Coupon List",
            "view_mode" : "tree,form",
            "type" : "ir.actions.act_window",
            "res_model" : "coupon.coupon",
            "domain" : [('partner_id.id','=',self.partner_id.id)],
            "context" : {"default_partner_id":self.partner_id.id},
            
        }    
        
    def helpdesk_ticket(self):
        return{
            "name" : "HelpDesk Tickets",
            "view_mode" : "tree,form",
            "type" : "ir.actions.act_window",
            "res_model" : "helpdesk.ticket",
            "domain" : [('passenger_id','=',self.id)],
            "context" : {"default_passenger_id":self.id},
            
        }     
    
    def compute_bookmark_counts(self):
        bookmark_counts = self.env['user.bookmark'].search([('user_name_','=',self.id)])
        self.bookmark_count_ = len(bookmark_counts)

    def button_user_bookmark(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'User Bookmark',
            'view_mode': 'tree,form',
            'res_model': 'user.bookmark',
            'domain': [('user_name_', '=', self.id)],
            'context': "{'create': False}"
        }
        
    def compute_history_counts(self):
        user_history_bookings = self.env['vb.book.master'].search([('customer_id','=',self.id)])
        self.booking_history_count = len(user_history_bookings)



    def user_booking_history(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Booking History',
            'view_mode': 'tree,form',
            'res_model': 'vb.book.master',
            'domain': [('customer_id','=',self.id)],
            'context': "{'create': False}"
        }

    
    def find_nearby_vehicles(self,user_id=None):
        user_id = self.search([('id','=',user_id)])
        # Radius of the Earth in kilometers
        earth_radius = 6371.0

        # Convert latitude and longitude from degrees to radians
        target_latitude_rad = math.radians(float(user_id.latitude))
        target_longitude_rad = math.radians(float(user_id.longitude))

        nearby_drivers = self.env['vb.driver.master'].search([])  # Replace with your actual model name

        nearby_drivers_within_radius = [(5,0,0)]
        for driver in nearby_drivers:
            driver_latitude_rad = math.radians(float(driver.latitude))
            driver_longitude_rad = math.radians(float(driver.longitude))

            # Haversine formula
            dlon = driver_longitude_rad - target_longitude_rad
            dlat = driver_latitude_rad - target_latitude_rad
            a = math.sin(dlat / 2)**2 + math.cos(target_latitude_rad) * math.cos(driver_latitude_rad) * math.sin(dlon / 2)**2
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
            distance = earth_radius * c
            if distance <= 2.0:
                data = {
                    'driver_id' : driver.id
                        }
                nearby_drivers_within_radius.append((0,0,data))
        self.tracking_vehicle_ids = nearby_drivers_within_radius
        
    
    
    
DRIVER_RATING = [
    ('0', 'Poor'),
    ('1', 'Normal'),
    ('2', 'Good'),
    ('3', 'Very Good'),
    ('4','Excellent'),
    ('5','Wonderful')
    ]

CUSTOMER_RATING =[
    ('0', 'Poor'),
    ('1', 'Normal'),
    ('2', 'Good'),
    ('3', 'Very Good'),
    ('4','Excellent'),
    ('5','Wonderful')
]


class FetchVehicle(models.Model):
    _name = 'user.vehicle.tracking'
    _rec_name = 'res_id'

    res_id = fields.Many2one('user.master',string='Res ID')
    driver_id = fields.Many2one('vb.driver.master',string="Driver") 




class vehicledrivermaster(models.Model):
    _name = 'vb.driver.master'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    
        
    current_driver_address = fields.Char(string="Booking Driver Address")
    license_number = fields.Char(string="License Number")
    license_expiry_date = fields.Date(string="Expiry Date of License")
    rc_book_number = fields.Char(string="RC Book Number Ride")
    rc_expiry_date = fields.Date(string="Rc Expiry Date Ride")
    insurance_expiry_date = fields.Date(string="Insurance Expiry Date Ride")
    rc_book_number_cargo = fields.Char(string="RC Book Number Cargo")
    rc_expiry_date_cargo = fields.Date(string="Rc Expiry Date Cargo")
    insurance_expiry_date_cargo = fields.Date(string="Insurance Expiry Date Cargo")
    account_number = fields.Char(string="Account Number")
    ifsc_code = fields.Char(string="IFSC Code")
    b64_data = fields.Char(string="Base 64 Data")
    online_time = fields.Datetime(string="Online Time")

# MEMBERSHIP
    driver_membership_id = fields.Many2one('membership.table',string='Driver Membership')
    validity = fields.Date(string="Validity")
    total_ride = fields.Integer(string="Total Ride")
    
    @api.onchange('driver_membership_id')
    def driver_membership(self):
        self.validity = self.driver_membership_id.validity
        self.total_ride = self.driver_membership_id.total_ride
    

    prime = fields.Boolean(string='Prime')
    pinky_ponnu = fields.Boolean(string='Pinky Ponnu')
    ride_allow = fields.Boolean(string='Ride Allow')
    cargo_allow = fields.Boolean(string='Cargo Allow')
    attachment_count = fields.Integer(string="Count Notification",compute="attachemnt_count_total")
    membership_ids = fields.One2many('membership.table', 'menbership_driver_id',string = "Membership",track_visibility='onchange',ondelete="cascade")
    
    
    def attachemnt_count_total(self):
        for record in self:
            record.attachment_count = self.env['driver.attachment'].search_count(
            [('driver_id', '=', record.id)])

    def attachment_details(self):
        return {
        'type': 'ir.actions.act_window',
        'name': 'Attachments',
        'view_mode': 'tree,form',
        'res_model': 'driver.attachment',
        'domain': [('driver_id', '=', self.id  )],
        'context': "{'create': False}"
        }
    
    driver_seq=fields.Char(string='Driver Sequence')
    
#CRON
    def license_expiry_reminder(self):
        driver_orm = self.env['vb.driver.master'].search([])
        today_date = date.today()
        for rec in driver_orm:
            if rec.license_expiry_date:
                if rec.license_expiry_date <= today_date:
                    data = {
                    'name' : f"License Expiry Notification for Driver {rec.name}",
                    'read_status' : "un_read",
                    'date' : date.today(),
                    'res_partner_id' : rec.partner_id.id,
                    'res_users' : rec.driver_user_id.id,
                    'manager' : True,
                    'driver_id' : rec.id,
                    'description' : f"Hello {rec.name} ,Your License has been Expired."
                    }
                    create_notification = self.env['notification.list'].create(data)
                
            if rec.rc_expiry_date:
                if rec.rc_expiry_date <= today_date:
                    data = {
                    'name' : f"RC Expiry Notification for Driver {rec.name}",
                    'read_status' : "un_read",
                    'date' : date.today(),
                    'res_partner_id' : rec.partner_id.id,
                    'res_users' : rec.driver_user_id.id,
                    'manager' : True,
                    'driver_id' : rec.id,
                    'description' : f"Hello {rec.name} ,Your RC has been Expired Soon. Please renewal it."
                    }
                    create_notification = self.env['notification.list'].create(data)
                
            if rec.rc_expiry_date_cargo:
                if rec.rc_expiry_date_cargo <= today_date:
                    data = {
                    'name' : f"RC Expiry Notification for Driver {rec.name}",
                    'read_status' : "un_read",
                    'date' : date.today(),
                    'res_partner_id' : rec.partner_id.id,
                    'res_users' : rec.driver_user_id.id,
                    'manager' : True,
                    'driver_id' : rec.id,
                    'description' : f"Hello {rec.name} ,Your RC has been Expired Soon. Please renewal it."
                    }
                    create_notification = self.env['notification.list'].create(data)
                
            if rec.insurance_expiry_date:
                if rec.insurance_expiry_date <= today_date:
                    data = {
                    'name' : f"Insurance Expiry Notification for Driver {rec.name}",
                    'read_status' : "un_read",
                    'date' : date.today(),
                    'res_partner_id' : rec.partner_id.id,
                    'res_users' : rec.driver_user_id.id,
                    'manager' : True,
                    'driver_id' : rec.id,
                    'description' : f"Hello {rec.name} ,Your Insurance has been Expired Soon. Please renewal it."
                    }
                    create_notification = self.env['notification.list'].create(data)
                
            if rec.insurance_expiry_date_cargo:
                if rec.insurance_expiry_date_cargo <= today_date:
                    data = {
                    'name' : f"Insurance Expiry Notification for Driver {rec.name}",
                    'read_status' : "un_read",
                    'date' : date.today(),
                    'res_partner_id' : rec.partner_id.id,
                    'res_users' : rec.driver_user_id.id,
                    'manager' : True,
                    'driver_id' : rec.id,
                    'description' : f"Hello {rec.name} ,Your Insurance has been Expired Soon. Please renewal it."
                    }
                    create_notification = self.env['notification.list'].create(data)
                
            if rec.validity:
                if rec.validity <= today_date:
                    rec.prime = False
                    rec.driver_membership_id = False
                    # rec.validity = False
                    rec.total_ride = False
                    data = {
                    'name' : f"Membership Expiry Notification for Driver {rec.name}",
                    'read_status' : "un_read",
                    'date' : date.today(),
                    'res_partner_id' : rec.partner_id.id,
                    'res_users' : rec.driver_user_id.id,
                    'manager' : True,
                    'driver_id' : rec.id,
                    'description' : f"Hello {rec.name} ,Your MemberShip has been Expired Soon. Please renewal it."
                    }
                    create_notification = self.env['notification.list'].create(data)
                    one_signal_data = rec.env['one.signal.master'].search([('driver_id','=',rec.id)])                  
                    for data in one_signal_data:
                        doc_key_idss = data.key
                        signal_val = data.signal_type
                        user_mode=data.user_mode
                        
                        if signal_val=='android' and user_mode=='driver':
                            url = "https://onesignal.com/api/v1/notifications"

                            payload = {
                                    "include_player_ids":[doc_key_idss],
                                    "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                                    "contents": {"en": f"Hello {rec.name} ,Your MemberShip has been Expired Soon. Please renewal it."},
                                    "headings": {"en": "Membership Expired"},
                                    "data": {"foo": "bar"},
                                    "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                                    "name": "INTERNAL_CAMPAIGN_NAME"
                                    }

                            headers = {
                                    "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                                    'Content-Type': 'application/json; charset=utf-8',
                                }
                            response = requests.post(url, json=payload, headers=headers)
                else:
                    pass
            
    def driver_sequence(self):
        self.driver_seq = f"{'DRP'}{self.env['ir.sequence'].next_by_code('driver.sequence.create')}"
    
    driver_user_id = fields.Many2one('res.users',string='Driver User ID',track_visibility='onchange')
    state = fields.Selection([('new',"Un Approved"),('approved',"Approved"),('on_hold',"On-Hold"),('rejected',"Rejected")],string="Status",track_visibility='onchange',default="new")
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo')],string="Vehicle Ride Type")
    ride_boolean = fields.Boolean(string="Ride Boolean")
    cargo_boolean = fields.Boolean(string="Cargo Boolean")
    cargo_online_offline = fields.Boolean(string="Cargo Online Offline")
    count_notification = fields.Integer(string="Count Notification",compute="count_driver_notification")
    complaint_count = fields.Integer(string="Count",compute="count_complaint")
    
    
    def on_hold_button(self):
        self.state = "on_hold"
        create_notification = self.env["notification.list"].create({
			'name' : "Driver is in On-Hold State",
			'read_status' : "un_read",
			'date' : date.today(),
			'driver_id' : self.id,
			'res_partner_id' : self.partner_id.id,
			'res_users' : self.user_id.id,
			'manager' : True,
			'description' : f"Hi {self.name},We are holding your approval process"
        })
        
    def count_driver_notification(self):
        for rec in self:
            self.count_notification = self.env["notification.list"].search_count([('driver_id','=',rec.id)])
    
    
    @api.onchange('current_driver_address')
    def _zip_code(self):
        for rec in self:
            if rec.current_driver_address:
                parts = rec.current_driver_address.split(',')
                zip_part = parts[-2].strip().split()[-1] if parts else ""
                if zip_part:
                    rec.zip_code=zip_part
    
    
    def count_complaint(self):
        for rec in self:
            rec.complaint_count = self.env['helpdesk.ticket'].search_count([('driver_id','=',rec.id)])
  
            
    def helpdesk_ticket(self):
        return{
            "name" : "HelpDesk Tickets",
            "view_mode" : "tree,form",
            "type" : "ir.actions.act_window",
            "res_model" : "helpdesk.ticket",
            "domain" : [('driver_id','=',self.id)],
            "context" : {"default_driver_id":self.id},
            
        }
    
    
    def count_notification_alert(self):
        return{
            "name" : "Alert Messages",
            "type" : "ir.actions.act_window",
            'view_mode' : "tree,form",
            "res_model" : "notification.list",
            "context" : {
                "default_driver_id" : self.id,
            },
            "domain" : [('driver_id','=',self.id)]
        }

    def approve_button(self):
        self.state = 'approved'
        if self.name:
            create_orm = self.env['notification.list'].create({
			'name' : "Driver has Been Approved",
            'status_id' : 'confirmed',
			'read_status' : "un_read",
			'date' : date.today(),
			'driver_id' : self.id,
			'res_partner_id' : self.partner_id.id,
			'res_users' : self.user_id.id,
			'manager' : True,
			'description' : "Driver <b>{}</b> has Been <b>Approved</b>".format(self.name)
            })

            
            if self.latitude and self.longitude:
                latitude = float(self.latitude)
                longitude = float(self.longitude)
                geolocator = Nominatim(user_agent="locator")
                # raise ValidationError(f"{latitude},{longitude}")
                location = geolocator.reverse(f"{latitude},{longitude}")
                address_data = location.raw['address']
                road = address_data.get('road', '')
                neighbourhood = address_data.get('neighbourhood', '')
                suburb = address_data.get('suburb', '')
                county = address_data.get('county', '')
                state_district = address_data.get('state_district', '')
                state = address_data.get('state', '')
                postcode = address_data.get('postcode', '')
                country = address_data.get('country', '')

                address_format = f"{neighbourhood} {suburb}"
                address_format = f"{road},{neighbourhood} {suburb}, {state_district}, {state} {postcode}, {country}"
                self.current_driver_address = str(address_format)

    def reject_button(self):
        self.state = 'rejected'   
        create_notification = self.env["notification.list"].create({    
			'name' : "Driver has Been Rejected",
			'read_status' : "un_read",
			'date' : date.today(),
			'driver_id' : self.id,
            'status_id' : 'cancel',
			'res_partner_id' : self.partner_id.id,
			'res_users' : self.user_id.id,
			'manager' : True,
			'description' : f"Hi {self.name},We are rejecting your approval process"
        })

    def new_button(self):
        self.state = 'new'  


    def ride_income_details(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Rides',
            'view_mode': 'tree,form',
            'res_model': 'vb.book.master',
            'domain': [('driver_id', '=', self.id),('booking_status','=','done')],
            'context': "{'create': False}"
        }

    def rides_income_total(self):
        for record in self:
            income = self.env['vb.book.master'].search(
                [('driver_id', '=', record.id),('booking_status','=','done')])
            record.ride_income = sum(list(income.mapped(lambda x:x.price)))

    ride_income = fields.Float(string="Income",compute="rides_income_total")
    wallet_balance=fields.Float(string="Wallet Balance")

    currency_id = fields.Many2one('res.currency', 'Currency',
                                default=lambda self: self.env.user.company_id.currency_id.id)      
    def rides_details(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Rides',
            'view_mode': 'tree,form',
            'res_model': 'vb.book.master',
            'domain': [('driver_id', '=', self.id  )],
            'context': "{'create': False,'group_by':['booking_status']}"
        }
    def rides_count_total(self):
        for record in self:
            record.ride_count = self.env['vb.book.master'].search_count(
                [('driver_id', '=', record.id)])

    aadhar_no = fields.Char(string ="Aadhar No")
    pan_no = fields.Char(string ="Pan No")

    ride_count = fields.Integer(compute='rides_count_total')
    image = fields.Binary(string="Image")
    name  = fields.Char(string = 'Name',required =True,track_visibility='onchange')
    age = fields.Float(string="Age",track_visibility='onchange')
    dob= fields.Date(string="DOB",track_visibility='onchange')
    gender = fields.Selection([('male',"Male"),('female',"Female"),('others',"Others")], string="Gender",track_visibility='onchange')
    phone = fields.Char('Phone',track_visibility='onchange')
    mobile = fields.Char('Mobile',track_visibility='onchange',required= True)
    email = fields.Char('Email',track_visibility='onchange',required= True)
    street_1 = fields.Char('Street1',track_visibility='onchange')
    street_2 = fields.Char('Street2',track_visibility='onchange')
    city = fields.Char('City',track_visibility='onchange')
    res_city = fields.Many2one('res.city',track_visibility='onchange')
    zip_code = fields.Char('Zip',track_visibility='onchange')
    state_id = fields.Many2one('res.country.state', string='State',track_visibility='onchange')
    country_id = fields.Many2one('res.country', string='Country',track_visibility='onchange')
    user_id = fields.Many2one('res.users', string= "User Id",track_visibility='onchange')
    partner_id = fields.Many2one('res.partner',string="Partner Id",track_visibility='onchange')
    user_type = fields.Selection([('driver',"Driver"),("user","User"),('admin',"Admin")], string="User Type",track_visibility='onchange',default = 'driver',readonly=True)
    driver_status = fields.Selection([('locked',"Locked"),('on_convo',"On Conversation"),('available',"Available")], string="Driver status",track_visibility='onchange')
    daily_status = fields.Selection([('active',"Active"),("inactive","Inactive")], string="Daily status",track_visibility='onchange')
    driving_license = fields.Char(string="Driving license No",track_visibility='onchange')
    attchment_ids = fields.One2many('driver.attachment', 'driver_id',string= "Attachments",track_visibility='onchange',ondelete="cascade")
    vehicle_id = fields.Many2one('vehicle.master',string="Vehicle Id",track_visibility='onchange')
    latitude=fields.Char(string="Latitude",track_visibility='onchange')
    longitude=fields.Char(string="Longitude",track_visibility='onchange')
    rating_ids = fields.One2many('driver.rating.lines', 'rating_drivers',string= "Rating",track_visibility='onchange',ondelete="cascade")

    availability=fields.Boolean(string='Availability')
    approve_boolean = fields.Boolean(string="Approve Button Visible",default=True)

    overall_rating = fields.Selection(DRIVER_RATING,'Partner Overall Rating',compute="_compute_overall_rating",store=True)
    current_booking_id = fields.Many2one('vb.book.master',string="Current Booking",track_visibility='onchange')
    license_expiry_date = fields.Date('Expiry Date')
    password = fields.Char(string="Password",track_visibility='onchange')
    company_name = fields.Char(string="Company Name")
    
    #driver track
    track_latitude = fields.Char(string="Track Latitude")
    track_longitude = fields.Char(string="Track longitude")
    track_rotation = fields.Float(string="Track Rotation")

    
    @api.depends('rating_ids.rating')
    def _compute_overall_rating(self):
        for driver in self:
            ratings = [int(line.rating) for line in driver.rating_ids]
            if ratings:
                overall_rating = round(sum(ratings) / len(ratings))
                driver.overall_rating = str(overall_rating)
            else:
                driver.overall_rating = '0'
                
    @api.constrains('vehicle_id','attchment_ids')
    def vehicle_assigning(self):
        for rec in self:
            if rec.vehicle_id:
                record_id = self.env['vehicle.master'].search([('id','=',self.vehicle_id.id)])
                if record_id:
                    record_id.availability = True
        flag_ride = True
        flag_cargo = True
    
        if self.attchment_ids:
            for rec in self.attchment_ids:
                if rec.vehicle_ride_type == "ride":
                    if rec.select_option == 'yes':
                        pass
                    else:
                        flag_ride = False
                        # break
                if rec.vehicle_ride_type == "cargo":
                    if rec.select_option == 'yes':
                        pass
                    else:
                        flag_cargo = False
                        # break
            if flag_ride == True or flag_cargo == True:
                self.approve_boolean = True
            elif flag_ride == False or flag_cargo == False:
                self.approve_boolean = False
        else:
            self.approve_boolean = True
                    
                    
    def compute_driver_position(self,driver_id=None):
        earth_radius = 6371.0
        driver_id = self.search([('id','=',driver_id)])

        # Convert latitude and longitude from degrees to radians
        target_latitude_rad = math.radians(float(driver_id.latitude))
        target_longitude_rad = math.radians(float(driver_id.longitude))
        passangers = driver_id.env['user.vehicle.tracking'].search([])
        for each in passangers:
            lattitude = math.radians(float(each.res_id.latitude))
            longitude = math.radians(float(each.res_id.longitude))
            # Haversine formula
            dlon = lattitude - target_longitude_rad
            dlat = longitude - target_latitude_rad
            a = math.sin(dlat / 2)**2 + math.cos(target_latitude_rad) * math.cos(lattitude) * math.sin(dlon / 2)**2
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
            distance = earth_radius * c
            if distance > 2:
                each.unlink()
            else:
                data = {
                    'res_id' : each.res_id,
                    'driver_id' : driver_id.id
                }
                self.env['user.vehicle.tracking'].create(data)
DRIVER_RATING = [
    ('0', 'Poor'),
    ('1', 'Normal'),
    ('2', 'Good'),
    ('3', 'Very Good'),
    ('4','Excellent'),
    ('5','Wonderful')
    ]

CUSTOMER_RATING =[
    ('0', 'Poor'),
    ('1', 'Normal'),
    ('2', 'Good'),
    ('3', 'Very Good'),
    ('4','Excellent'),
    ('5','Wonderful')
]

class customerratingdriver(models.Model):
    _name = 'driver.rating.lines'

    rating_drivers = fields.Many2one('vb.driver.master',string='Driver Rating')
    username = fields.Many2one('res.partner',string="Name")
    rating = fields.Selection(CUSTOMER_RATING,'RATING',default='0')
    comment = fields.Text(string="Comment")
    image = fields.Many2many('ir.attachment',string="Images")
    date_created = fields.Datetime(string="Date Added",default=datetime.now())    

    # @api.onchange("username")
    # def _check(self):
    #     for rec in self.search([]):
    #         rec.rating = None


SELECT =[
    ('yes', 'Yes'),
    ('no', 'No'),
    ('re_upload', 'Re-Upload')
]
class driverattachment(models.Model):
    _name = 'driver.attachment'
    _rec_name = 'name'

    name  = fields.Char(string = 'Name',required =True,track_visibility='onchange')
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo')],string="Vehicle Ride Type")
    driver_id= fields.Many2one('vb.driver.master')
    #ir.attchement 
    attachment_id = fields.Many2many('ir.attachment',string="Images")
    # attachment_id_kanban = fields.Many2many(comodel_name = 'ir.attachment',relation='attachment',column1='photo',column2='image',string="Images Kanban",invisible='1')
    
    
    # @api.constrains('attachment_id')
    # def attachment_constraints(self):
    #     list_1 = [(5, 0, 0)]
    #     for obj in self.attachment_id:
    #         list_1.append((4, obj.id))
    #     self.attachment_id_kanban = list_1
                
    attachment_success = fields.Boolean(string="Successfull")
    select_option = fields.Selection(SELECT,string="Approve",default='no')
    expiry_date = fields.Date(string='Expiry Date', copy=False)
    color_field = fields.Integer(string="Color",invisible=True)
    approve_boolean = fields.Boolean(string="Approve Document")
    
    @api.onchange('approve_boolean')
    def onchange_approve(self):
        if self.approve_boolean == True:
            self.select_option = 'yes'
            if self.name == "Profile Photo With Vehicle":
                if self.vehicle_ride_type == 'ride':
                    for rec in self.attachment_id:
                        ir_attachment_orm_ride = self.env['ir.attachment'].sudo().search([('id','=',rec._origin.id)])
                        vehicle_master_orm_ride = self.env['vehicle.master'].search([('owner.id','=',self.driver_id._origin.id),('ride_boolean','=',True)])
                        vehicle_master_orm_ride.write({
                            'profile' : ir_attachment_orm_ride.datas
                        })
                elif self.vehicle_ride_type == 'cargo':
                    for rec in self.attachment_id:
                        ir_attachment_orm_cargo = self.env['ir.attachment'].sudo().search([('id','=',rec._origin.id)])
                        vehicle_master_orm_cargo = self.env['vehicle.master'].search([('owner.id','=',self.driver_id._origin.id),('cargo_boolean','=',True)])
                        vehicle_master_orm_cargo.write({
                            'profile' : ir_attachment_orm_cargo.datas
                        })
                else:
                    pass
            else:
                pass
            if self.name == 'RC Book Front' or self.name == 'RC Book Back':
                create_orm = self.env['notification.list'].create({
                    'name' : "RC Book",
                    'res_users' : self.driver_id.user_id.id,
                    'res_partner_id' : self.driver_id.partner_id.id,
                    'description' : f"RC Book Approved Successfully!!!",
                    'res_users' : self.driver_id.driver_user_id.id,
                    'driver_id' : self.driver_id._origin.id,
                    'manager' : True,
                })
            else:
                create_orm = self.env['notification.list'].create({
                    'name' : self.name,
                    'res_users' : self.driver_id.user_id.id,
                    'res_partner_id' : self.driver_id.partner_id.id,
                    'description' : f"{self.name} Approved Successfully!!!",
                    'res_users' : self.driver_id.driver_user_id.id,
                    'driver_id' : self.driver_id._origin.id,
                    'manager' : True,
                })
        else:
            self.select_option = 'no'
    # @api.onchange('select_option')
    # def create_notification(self):
    #     if self.name and self.select_option == 'yes':
    #         create_orm = self.env['notification.list'].create({
    #             'name' : self.name,
    #             'res_users' : self.driver_id.user_id.id,
    #             'res_partner_id' : self.driver_id.partner_id.id,
    #             'description' : f"{self.name} Approved Successfully!!!"
    #         })
            
class MemberShipTable(models.Model):
    _name = 'membership.table'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    

    menbership_driver_id = fields.Many2one('vb.driver.master',string='Membership Ids')
    name = fields.Char(string="Name",required=True)
    savings = fields.Float(string="Savings")
    price = fields.Float(string="Price")
    description = fields.Char(string="Description")
    discount = fields.Float(string="Discount %")
    validity = fields.Date(string="Validity")
    total_ride = fields.Integer(string="Total Ride")
    
class SOSMaster(models.Model):
    _name = 'sos.master'
    _rec_name='name'
    _inherit = ['mail.thread','mail.activity.mixin']
    
    user_master_id = fields.Many2one('user.master',string="User Master ID")
    name = fields.Char(string="Name",track_visibility="onchange")
    phone_number = fields.Char(string="Phone Number",track_visibility="onchange")