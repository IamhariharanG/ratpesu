from odoo import fields,models,api

class PaymentTransactionDetails(models.Model):
    _name = "payment.transaction.model"
    _inherit = ["mail.thread","mail.activity.mixin"]
    _rec_name = "booking_id"
    _description = "Payment"
    
    booking_id = fields.Many2one('vb.book.master',string="Booking ID",track_visibility="onchange")
    key_id = fields.Char(string="Key",track_visibility="onchange")
    customer_id = fields.Many2one('user.master',string="Customer Id",track_visibility="onchange")
    price = fields.Float(string="Price",track_visibility="onchange")
    status = fields.Selection([('draft','Draft'),('post','Posted')],string="Status",track_visibility="onchange",default='draft')
    
    
    def payment_post(self):
        self.status = "post"
    
    def payment_draft(self):
        self.status = "draft"