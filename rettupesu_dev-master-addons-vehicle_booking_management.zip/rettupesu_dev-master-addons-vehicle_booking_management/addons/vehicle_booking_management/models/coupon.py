from odoo import fields, models, api
from odoo.exceptions import ValidationError


class CouponInherit(models.Model):
    _inherit = "coupon.program"
    
    image = fields.Binary(string="Image")
    description = fields.Text(string="Description")
    terms = fields.Text(string="Terms & Condition")