from odoo import models, fields, api
from datetime import datetime , timedelta
import requests
import json
from odoo.exceptions import ValidationError
import math
import random


class vehiclebook(models.Model):
    _name = 'vb.book.master'
    _rec_name = 'booking_seq'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    DRIVER_RATING = [
    ('0', 'Poor'),
    ('1', 'Normal'),
    ('2', 'Good'),
    ('3', 'Very Good'),
    ('4','Excellent'),
    ('5','Wonderful')
    ]
    overall_rating = fields.Selection(DRIVER_RATING,'Partner Overall Rating',store=True)
    vehicle_type_id = fields.Many2one("vehicle.type",string="Vehicle Type")
    customer_id = fields.Many2one('user.master', string= "Customer",track_visibility='onchange')
    driver_id = fields.Many2one('vb.driver.master',string="Driver",track_visibility='onchange')
    driver_user_id = fields.Many2one('res.users', string= "Driver User Id",track_visibility='onchange')
    customer_user_id = fields.Many2one('res.users', string= "Customer User Id",track_visibility='onchange')
    vehicle_category =fields.Many2one('vehicle.category',string="Vechicle Category",track_visibility='onchange')
    round_trip = fields.Boolean(string="Round Trip")
    driver_fee_per_day = fields.Float(string="Driver Fee per Day")
    coupon_applied_price = fields.Float(string="Coupon Price")

    vehicle_type =fields.Many2one('vehicle.type',string="Vechicle Type",track_visibility='onchange')
    vehicle_id =fields.Many2one('vehicle.master',string="Vechicle",track_visibility='onchange')
    location  = fields.Char(string = 'Location',track_visibility='onchange')
    km = fields.Char(string="km",track_visibility='onchange')
    pickup_location= fields.Char(string="Pickup Location",track_visibility='onchange')
    drop_location= fields.Char(string="Drop Location",track_visibility='onchange')
    booking_date = fields.Datetime(string="Conform Time",track_visibility='onchange')
    start_time = fields.Datetime(string="Start Time",track_visibility='onchange')
    cancel_time = fields.Datetime(string="Cancel Time",track_visibility='onchange')
    end_time = fields.Datetime(string="End time",track_visibility='onchange')
    price = fields.Float(string="Price",track_visibility='onchange')
    payment_mode= fields.Selection([('online',"Online"),('cash',"Cash")],string="Payment Mode",track_visibility='onchange')
    payment_status= fields.Selection([('paid',"paid"),('process',"Process"),('pending',"Pending")],string="Payment Status",track_visibility='onchange')
    booking_status= fields.Selection([('schedule',"Scheduled"),('draft',"Draft"),('confirm',"Confirm"),('reached',"Reached"),('transit',"In Transit"),('complete',"Complete"),('done',"Done"),('cancel',"Cancel")],readonly=True,string="Status",track_visibility='onchange',default='draft'
    )
    booking_type = fields.Selection([('auto','Auto'),('car','AC Ride'),('moto','Moto'),('out','Outstation'),('parcel','Freight')],string="Booking Type")
    book_type = fields.Many2one("booking.type",string="Booking Type")
    booking_chat_ids = fields.One2many('mail.message','booking_id','Booking Conversation',tracking=True,ondelete='cascade')
    driver_transaction_ids = fields.One2many('vb.driver.transaction','booking_id','Driver Transaction',tracking=True,ondelete='cascade')
    vehicle_transaction_ids = fields.One2many('vb.vehicle.transaction','booking_id','Vehicle Transaction',tracking=True,ondelete='cascade')
    current_position=fields.Char(string="Current Position",track_visibility='onchange')
    vehicle_size=fields.Char(string="Parcel Size",track_visibility='onchange')

    goods_transfer_ids = fields.One2many('picking.transit','booking_id','Goods Transaction',tracking=True,ondelete='cascade')
    #pick and dest
    pick_latitude = fields.Char(string="Pick Latitude")
    pick_longitude = fields.Char(string="Pick longitude")
    dest_latitude = fields.Char(string="Dest Latitude")
    dest_longitude = fields.Char(string="Dest longitude")
    
    #receiver details
    receiver_name = fields.Char(string="Receiver Name")
    receiver_phone_number = fields.Char(string="Receiver Phone Number")
    receiver_address = fields.Char(string="Receiver Address")
    receiver_gst_no = fields.Char(string="Receiver GST No")
    e_way_bill_no = fields.Char(string="E-Way Bill No")
    move_type = fields.Selection([('home','Home'),('shop','Shop'),('other','Others')],string="Move Type")
    # use_my_number = fields.Boolean(string="Use My Number")

    comment = fields.Char(string="Comment and Option")
    pickup_time = fields.Datetime(string="Pickup Time")
    passenger_count = fields.Integer(string="No of Passenger")
    customer_offer = fields.Float(string="Market Base Price")
    outstation_type = fields.Selection([('private','Private Ride'),('parcel','Parcel')],string="Outstation Type")
    customer_latitude = fields.Char(string="Customer Latitude")
    customer_longitude = fields.Char(string="Customer Longitude")
    cancelled_reason=fields.Many2one('booking.cancel.reason',string="Cancelled Reason")
    coupon_id = fields.Many2one('coupon.coupon', string="Apply Coupon")
    promotion_id = fields.Many2one('coupon.program', string="Apply Promotion")
    car_type= fields.Selection([('mini',"Mini"),('sedan',"Sedan"),('suv','SUV')],string="Car Type",track_visibility='onchange')
    booking_seq=fields.Char(string='Booking Sequence')
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo'),('out','Outstation')],string="Vehicle Ride Type")
    cargo_online_offline = fields.Boolean(string="Cargo Online Offline")
    schedule_time = fields.Datetime(string="Scheduled Time")
    return_time = fields.Datetime(string="Return Time")
    cancel_by = fields.Selection([('driver','Driver'),('passenger','Passenger')],string="Cancel By")
    #otp creation 
    otp=fields.Integer(string="OTP",readonly=True)
    donation_amount = fields.Integer(string="Donation Amount")
    #min_bid
    min_bid_amount = fields.Integer(string="Min Bid Amount")
    base_price = fields.Float(string="Base Price")
    
    #outstation
    is_round_trip = fields.Boolean(string="Round Trip")
    

    def booking_smart_view(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Negotiation',
            'view_mode':'tree,form',
            'res_model':'chat.negotiation',
            'domain': [('booking_id', '=', self.id)],
        } 

    def booking_sequence(self):
        self.booking_seq= f"{'RPB'}{self.env['ir.sequence'].next_by_code('book.sequence.create')}"
    
    def compute_channel_creation(self,booking_id=None):
        booking_id=self.search([('id','=',booking_id)])
        if booking_id.booking_status=='confirm':
            customer_id=booking_id.customer_id.id
            driver_id=booking_id.driver_id.id

            driver_read = self.env['vb.driver.master'].search([('id','=',int(driver_id))])
            driver_partner_id=driver_read.partner_id.id

            customer_read = self.env['user.master'].search([('id','=',int(customer_id))])
            customer_partner_id=customer_read.partner_id.id
            
            data = {
                'name' : f"{booking_id.booking_seq}-Chat",
                'public' : 'groups',
                'booking_id':booking_id.id
                    }
            create_channel = self.env['mail.channel'].sudo().create(data)
            chat_ids=[driver_partner_id,customer_partner_id]
            members = [(5,0,0)]
            for i in chat_ids:
                line_data = {
                            'partner_id' :i,
                        }
                members.append((0,0,line_data))
            create_channel.channel_last_seen_partner_ids=members
    
    def cancel_booking(self):
        return {
            'name': 'Cancel Reason',
            'type': 'ir.actions.act_window',
            'res_model': 'cancel.wizard.view',
            'view_mode': 'form',
            'context': {
                        'default_customer_wizard_cancel':self.customer_id.id,
                        'default_vb_master_id':self.id,
                        },
            'target': 'new',
        }

    # ...
    # web
    fair_price = fields.Float(string='BID Price',compute='amount_per_km', store=True,readonly=False)
     
    @api.onchange('coupon_id')
    def coupon_fair(self):
        for rec in self:
            if rec.coupon_id:
                if rec.coupon_id.program_id.discount_type == "percentage":
                    rec.price = rec.fair_price - (rec.fair_price*(rec.coupon_id.program_id.discount_percentage / 100))
                if rec.coupon_id.program_id.discount_type == "fixed_amount":
                    rec.price = rec.fair_price - rec.coupon_id.program_id.discount_fixed_amount

    @api.onchange('promotion_id')
    def promotion_fair(self):
        for rec in self:
            if rec.promotion_id:
                if rec.promotion_id.discount_type == "percentage":
                    rec.price = rec.fair_price - (rec.fair_price*(rec.promotion_id.discount_percentage / 100))
                if rec.promotion_id.discount_type == "fixed_amount":
                    rec.price = rec.fair_price - rec.promotion_id.discount_fixed_amount

    
    
    @api.constrains('km')
    def amount_per_km(self):
        for rec in self:
            if rec.km:
                record_id = self.env['pre.set.master'].search([('vehicle_booking_type','=',rec.booking_type)])
                if record_id:
                    rec.fair_price = record_id.cost_per_km * int(rec.km)
                    

    @api.model
    def driver_state(self):
        for rec in self:
            if rec.booking_status=='done':
                record_id = self.env['vb.driver.master'].search([('id','=',self.driver_id.id)])
                if record_id:
                    record_id.current_booking_id = None
                    record_id.driver_status='active'
                    
    
    @api.constrains('driver_id')
    def driver_assign(self):
        for rec in self:
            if rec.driver_id:
                record_id = self.env['vb.driver.master'].search([('id','=',self.driver_id.id)])
                if record_id:
                    record_id.current_booking_id = rec._origin.id
                    record_id.driver_status = 'locked'


    def start_trip(self):
        self.driver_id.current_booking_id = self._origin.id
        self.driver_id.driver_status = 'locked'
        self.start_time = datetime.now()
        self.booking_status = 'transit'        

    
    def end_trip(self):
        self.driver_id.current_booking_id = None
        self.driver_id.driver_status = 'available'
        self.end_time = datetime.now()
        self.booking_status = 'done' 
        if not self.start_time:
            raise ValidationError("You cannot 'Complete trip' without Started")         
        
        
    def confirm_booking(self):
        self.booking_date = datetime.now()
        self.booking_status = 'confirm'      
        if self.coupon_id:
            self.coupon_id.state = "used"    
            
    def reached_button(self):
        self.booking_status = 'reached'


    @api.onchange('driver_id')
    def _vehicle(self):
        self.vehicle_id = self.driver_id.vehicle_id
        self.vehicle_type = self.vehicle_id.type_id
        
    
    def find_nearby_vehicles(self):
        # Radius of the Earth in kilometers
        earth_radius = 6371.0

        # Convert latitude and longitude from degrees to radians
        target_latitude_rad = math.radians(float(self.customer_id.latitude))
        target_longitude_rad = math.radians(float(self.customer_id.longitude))

        nearby_vehicles = self.env['vehicle.master'].search([])  # Replace with your actual model name

        nearby_vehicles_within_radius = [(5,0,0)]
        for vehicle in nearby_vehicles:
            vehicle_latitude_rad = math.radians(float(vehicle.latitude))
            vehicle_longitude_rad = math.radians(float(vehicle.longitude))

            # Haversine formula
            dlon = vehicle_longitude_rad - target_longitude_rad
            dlat = vehicle_latitude_rad - target_latitude_rad
            a = math.sin(dlat / 2)**2 + math.cos(target_latitude_rad) * math.cos(vehicle_latitude_rad) * math.sin(dlon / 2)**2
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
            distance = earth_radius * c

            if distance <= 2.0:
                data = {
                                    'date' : datetime.now(),
                                    'vehicle_id' : vehicle.id,
                                    'vehicle_logitude' : vehicle.longitude,
                                    'vehicle_latitude' : vehicle.latitude,
                                    'vehicle_status' : 'booked',
                                    'booking_id' : self.id,
                                    'amount' : self.price,
                                }
                nearby_vehicles_within_radius.append((0,0,data))
        self.vehicle_transaction_ids = nearby_vehicles_within_radius
        # return nearby_vehicles_within_radius

    def get_base_fair(self,distance=None):
        vehicle_types = self.env['pre.set.master'].search([('book_type.vehicle_ride_type','=','ride')])
        data = [{'km':distance,'market_fair' : int((vehicle.cost_per_km * distance)+vehicle.booking_fee) ,'tag':vehicle.tag,'vehicle_type':vehicle.vehicle_category.category_name,'vehicle_id':vehicle.vehicle_category.id,"booking_type":vehicle.book_type.id} for vehicle in vehicle_types]
        return data
    
    def _outstation_base_price(self,distance=None,days = None):
        vehicle_types = self.env['pre.set.master'].search([('book_type.vehicle_ride_type','=','outstation')])
        data = [{'km':distance,'market_fair' : int((vehicle.cost_per_km * distance)+vehicle.booking_fee+(vehicle.waiting_day_fee*days)) ,'tag':vehicle.tag,'vehicle_type':vehicle.vehicle_category.category_name,'vehicle_id':vehicle.vehicle_category.id,"booking_type":vehicle.book_type.id} for vehicle in vehicle_types]
        return data

    #cron for reminder scheduled booking
    def booking_reminder(self):
        ref_time = (datetime.now() + timedelta(hours=5,minutes=35)).replace(second=0,microsecond=0)
        reminders = self.search([('booking_status','=','schedule'),('schedule_time','>=',datetime.now()),('schedule_time','<=',ref_time)])
        # raise ValidationError(reminders)
        for ids in reminders:
            data = {
                'customer_id' : ids.customer_id.id,
                'user' : True,
                'booking_id': ids.id,
                'date':datetime.now().date(),
                'name' : f"Reminder for Booking",
                'description':f"Reminter to book ride from {ids.pickup_location} to {ids.drop_location}"
            }
            self.env['notification.list'].create(data)
            one_signal_data = self.env['one.signal.master'].search([('passenger_id','=',ids.customer_id.id)])                  
            for data in one_signal_data:
                doc_key_idss = data.key
                signal_val = data.signal_type
                user_mode=data.user_mode
                
                if signal_val=='android' and  user_mode=='passenger':
                    url = "https://onesignal.com/api/v1/notifications"

                    payload = {
                            "include_player_ids":[doc_key_idss],
                            "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                            "contents": {"en": f"Reminter to book ride from {ids.pickup_location} to {ids.drop_location}"},
                            "headings": {"en": f"Reminder for Booking"},
                            "data": {"foo": "bar"},
                            "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                            "name": "INTERNAL_CAMPAIGN_NAME"
                            }

                    headers = {
                            "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                            'Content-Type': 'application/json; charset=utf-8',
                        }
                    response = requests.post(url, json=payload, headers=headers)


class vehiclebooking_mail(models.Model):
    _inherit = 'mail.message'

    booking_id = fields.Many2one('vb.book.master',string="Booking Id")
    
    
#driver tranaction one2many list
class driver_transaction(models.Model):
    _name = 'vb.driver.transaction'
    _rec_name = 'driver_id'
    _inherit = ['mail.thread', 'mail.activity.mixin',]

    driver_id = fields.Many2one('vb.driver.master',string="Driver",track_visibility='onchange')
    driver_status = fields.Selection([('booked',"Booked"),("available","Available"),("removed","Removed")],string="Driver Status",track_visibility='onchange',default="available")
    booking_id = fields.Many2one('vb.book.master',string="Booking",track_visibility='onchange')
    amount = fields.Float(string="Amount",track_visibility='onchange')
    driver_amount = fields.Float(string="Driver Amount",track_visibility='onchange')
    date = fields.Datetime(string="Date",track_visibility='onchange',default=datetime.now())
    payment_mode = fields.Selection([('online',"Online"),('cash',"Cash")],string="Payment Mode",track_visibility='onchange')
    payment_status = fields.Selection([('paid',"paid"),('pending',"Pending")],string="Payment Status",track_visibility='onchange')
    transaction_status = fields.Selection([('paid',"paid"),('pending',"Pending")],string="Transaction Status",track_visibility='onchange')
    user_type = fields.Selection([('driver',"Driver"),('customer',"Customer")],string="Type Users")
    request_status= fields.Selection([('yes',"Yes"),('no',"No")],string="Request Status",track_visibility='onchange')
    
    
    #ETA
    eta = fields.Integer(string="ETA")
    km = fields.Float(string="KM")
    

    def conform_book(self):
        self.booking_id.driver_id = self.driver_id.id
        self.booking_id.vehicle_id = self.driver_id.vehicle_id.id
        self.booking_id.booking_status = 'confirm' 
        self.booking_id.fair_price = self.amount
        self.booking_id.price = self.amount
        self.booking_id.driver_id.current_booking_id = self.booking_id.id
        
#vehicle transaction one2many list
class vehicle_transaction(models.Model):
    _name = 'vb.vehicle.transaction'
    _rec_name = 'vehicle_id'
    _inherit = ['mail.thread', 'mail.activity.mixin',]

    vehicle_id = fields.Many2one('vehicle.master',string="Vehicle",track_visibility='onchange')
    vehicle_logitude = fields.Char(string="Vehicle Logitude",track_visibility='onchange')
    vehicle_latitude = fields.Char(string="Vehicle Latitude",track_visibility='onchange')
    vehicle_status = fields.Selection([('booked',"Booked"),("available","Available"),("removed","Removed")],string="Vehicle Status",track_visibility='onchange',default="available")
    booking_id = fields.Many2one('vb.book.master',string="Booking",track_visibility='onchange')
    amount = fields.Float(string="Amount",track_visibility='onchange')
    date = fields.Datetime(string="Date",track_visibility='onchange',default=datetime.now())
    payment_mode= fields.Selection([('online',"Online"),('cash',"Cash")],string="Payment Mode",track_visibility='onchange')
    payment_status= fields.Selection([('paid',"paid"),('pending',"Pending")],string="Payment Status",track_visibility='onchange')
    transaction_status= fields.Selection([('paid',"paid"),('pending',"Pending")],string="Transaction Status",track_visibility='onchange')
    
    
class PickDrop(models.Model):
    _name = 'picking.transit'
    _rec_name = 'operation_type'
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    
    operation_type = fields.Selection([('pick','Picking'),('drop','Delivery')],string="Operation")
    # lattitude = fields.Char(string="Lattitude")
    latitude = fields.Char(string="Latitude")
    longitude = fields.Char(string="Longitude")
    done = fields.Boolean(string="Done")
    attachment_ids = fields.Many2many("ir.attachment",string="Attachment")
    
    booking_id = fields.Many2one('vb.book.master',string="Booking",ondelete="cascade")
    
    
class pre_set_master(models.Model):
    _name = "pre.set.master"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'vehicle_category'

    cost_per_km = fields.Float(string='Cost Per KM',required=True)
    vehicle_booking_type = fields.Selection([('auto','Auto'),('car','AC Ride'),('moto','Moto'),('out','Outstation'),('parcel','Freight')],string="Booking Type")
    book_type = fields.Many2one("booking.type",string="Booking Type")
    vehicle_category = fields.Many2one('vehicle.category',string="Vechicle Category",track_visibility='onchange')
    tag = fields.Char(string="Tag")
    description = fields.Html(string="Description")
    wallet_min_balance = fields.Float(string="Minimum Balance")    
    booking_fee = fields.Float(string="Booking Fee")
    waiting_day_fee = fields.Float(string="Driver Fee Per Day")
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo'),('outstation','Outstation')],related="book_type.vehicle_ride_type",string="Vehicle Ride Type")
    base_fair_discount = fields.Float(string="Base Fair Discount")    
    # max_ride_distance = fields.Integer(string="Max Ride Distance")    
    
   
    @api.onchange('cost_per_km')
    def double_the_value(self):
        if self.cost_per_km and self.vehicle_ride_type == 'outstation':
            self.cost_per_km *= 2.0
    @api.constrains('wallet_min_balance')
    def wallet_min_balance_update(self):
        wallet_ids = self.env['wallet.wallet'].search([('driver_id.vehicle_id.type_id.category','=',self.vehicle_category.id)])
        wallet_ids.write({'wallet_min_balance':self.wallet_min_balance})


    
class Booking_inherit_mailchannel(models.Model):
    _inherit = 'mail.channel'

    booking_id = fields.Many2one('vb.book.master',string="Booking")   
