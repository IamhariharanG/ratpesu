from odoo import models,fields,api

class cabcategory(models.Model):
    _name = 'vehicle.category'
    _rec_name = 'category_name'
    _inherit = ['mail.thread', 'mail.activity.mixin',]

    image = fields.Binary(string="Image")
    category_name=fields.Char(string="Category Name")
    booking_type = fields.Selection([('auto','Auto'),('car','AC Ride'),('moto','Moto'),('out','Outstation'),('parcel','Freight')],string="Vehicle Type")
    book_type = fields.Many2one("booking.type",string="Booking Type")
    vehicle_ride_type = fields.Selection([('ride','Ride'),('cargo','Cargo'),('outstation','Outstation')],related="book_type.vehicle_ride_type",string="Vehicle Ride Type")
    