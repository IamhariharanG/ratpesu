from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import ValidationError

class userbookmark(models.Model):
    _name = 'user.bookmark'
    _rec_name = 'user_name_'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    user_name_ = fields.Many2one('user.master', string= "User",track_visibility='onchange',required=True)
    address_type=fields.Selection([('home',"Home"),('company',"Company"),('others',"Others")],string="Address Type",tracking=True)
    other_address_type=fields.Char(string="Other Address")
    user_street=fields.Char(string="Street",tracking=True)
    user_place=fields.Char(string="Street2",tracking=True)
    user_city=fields.Char(string="City",tracking=True)
    user_country_state=fields.Many2one('res.country.state',string="State",tracking=True)
    user_zip_code=fields.Char(string="Zip-Code",tracking=True)
    user_country=fields.Many2one('res.country',string="Country",tracking=True)
    lattitude=fields.Char(string="Lattitude")
    longitude=fields.Char(string="Longitude")