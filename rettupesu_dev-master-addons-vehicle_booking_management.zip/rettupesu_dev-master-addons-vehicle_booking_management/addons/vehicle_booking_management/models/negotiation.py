from odoo import fields, models, api
from odoo.exceptions import ValidationError



class NegotiationChat(models.Model):
    _name = "chat.negotiation"
    _rec_name = "booking_id"
    
    booking_id = fields.Many2one("vb.book.master",string="Booking",required=True)
    user_type=fields.Selection([('passenger','Passenger'),('driver','Driver')])
    # passenger_id = fields.Many2one("user.master",string="Passenger")
    driver_id = fields.Many2one("vb.driver.master",string="Driver")
    bid_line_id = fields.Many2one("vb.driver.transaction",string="Driver")
    message = fields.Char(string="message")


    
    