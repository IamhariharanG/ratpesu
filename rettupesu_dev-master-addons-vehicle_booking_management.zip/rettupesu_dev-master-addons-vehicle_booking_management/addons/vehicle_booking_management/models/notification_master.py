from odoo import fields,api,models

class DemoMaster(models.Model):
    _name = "notification.master"
    _inherit = ["mail.thread","mail.activity.mixin"]
    _rec_name = "user_id"
    _description = "Notification"
    
    user_id = fields.Many2one('user.master',string="User Name")
    general = fields.Boolean(string="General Notification")
    sound = fields.Boolean(string="Sound")
    vibrate = fields.Boolean(string="Vibrate")
    special_offfer = fields.Boolean(string="Special Offer")
    promo_discount = fields.Boolean(string="Promo & Discount")
    payments = fields.Boolean(string="Payments")
    cashback = fields.Boolean(string="CashBack")
    app_updates = fields.Boolean(string="App Updates")
    new_service = fields.Boolean(string="New Service")
