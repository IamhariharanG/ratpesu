from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class wizard_button(models.TransientModel):
    _name='cancel.wizard.view'


    customer_wizard_cancel=fields.Many2one('user.master',string="Customer")
    wizard_cancelled_reason=fields.Many2one('booking.cancel.reason',string="Cancel Reason")
    vb_master_id=fields.Many2one('vb.book.master',string="ID")
    
    def wizard_to_create(self):
        for rec in self:
            if rec.customer_wizard_cancel:
                search_id_customer_= self.env['vb.book.master'].search([('id','=',rec.vb_master_id.id)])
                if search_id_customer_:
                    search_id_customer_.booking_status="cancel"
                    search_id_customer_.write({'cancelled_reason':rec.wizard_cancelled_reason.id}
                    )
                if search_id_customer_.driver_id:
                    search_id_customer_.driver_id.current_booking_id = None
                    