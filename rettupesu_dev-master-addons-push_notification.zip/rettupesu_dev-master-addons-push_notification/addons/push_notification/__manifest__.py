{
    "name": "Push Notification",
    "summary": "Notifications For User And Driver",
    "version": "14.0.1.24.0",
    "license": "AGPL-3",
    "category":"",
    "author": "Scopex",
    "website": "None",
    "depends": ["base","mail","firebase_push_notification"],
    "data": [
        "security/ir.model.access.csv",
        'views/push_notification.xml',

    ],
    "application": True,
}