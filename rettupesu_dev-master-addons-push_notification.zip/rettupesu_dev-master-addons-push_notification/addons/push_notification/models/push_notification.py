from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import ValidationError
import requests
class pushnotify(models.Model):
    _name = 'push.notification'
    _rec_name = 'content'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Push Notification"

    content=fields.Char("Content")
    type=fields.Selection([('all','All'),('customer','Customer'),('driver','Driver')],string="Type")
    image = fields.Binary(string="Image")
    latitude = fields.Char(string="Latitude")
    longitude = fields.Char(string="Longitude")
    pin_code = fields.Char(string="Pin Code")
    background_image = fields.Boolean(string="Background Image")


    

    def offer_send(self):
        if self.type=='customer':
            self.customer_notify_push()
        if self.type=='driver':
            self.driver_notify_push()
        if self.type=='all':
            self.customer_notify_push()
            self.driver_notify_push()

    def customer_notify_push(self):
        for rec in self:
            customer_records = self.env['user.master'].search([])
            for customer in customer_records:
                customer_content={
                    'name':rec.content,
                    'customer_id':customer.id,
                    'res_users':customer.user_id.id,
                    'res_partner_id':customer.partner_id.id, 
                    'user':True,
                    "status_id" : "offer_notification",
                    "read_status" : "un_read",
                    "date" : datetime.now().date(),
                    'image':rec.image
                }
                customer_notification=self.env['notification.list'].create(customer_content)
                one_signal_data = rec.env['one.signal.master'].search([('passenger_id','=',customer.id)])                  
                for data in one_signal_data:
                    doc_key_idss = data.key
                    signal_val = data.signal_type
                    user_mode=data.user_mode
                    
                    if signal_val=='android' and  user_mode=='passenger':
                        url = "https://onesignal.com/api/v1/notifications"

                        payload = {
                                "include_player_ids":[doc_key_idss],
                                "app_id":"7870e0f9-c5a8-434e-8c89-a8ba7b92c0fc",
                                "contents": {"en": f"{rec.content}"},
                                "headings": {"en": "Ratepesu"},
                                "data": {"foo": "bar"},
                                "large_icon": 'https://www.pngwing.com/en/free-png-bnzxj',
                                "name": "INTERNAL_CAMPAIGN_NAME"
                                }

                        headers = {
                                "Authorization": "Basic NzQ3MmQzZmItMmU1OC00ZjI1LWI5OWUtZGFhNjFmYWM5NzI1",
                                'Content-Type': 'application/json; charset=utf-8',
                            }
                        response = requests.post(url, json=payload, headers=headers)

    def driver_notify_push(self):
        for rec in self:
            driver_records = self.env['vb.driver.master'].search([('state','=','approved')])
            for driver in driver_records:
                driver_content={
                    'name':rec.content,
                    'driver_id':driver.id,
                    'res_users':driver.driver_user_id.id,
                    'res_partner_id':driver.partner_id.id, 
                    'manager':True,
                    "status_id" : "offer_notification",
                    "read_status" : "un_read",
                    "date" : datetime.now().date(),
                    'image':rec.image,
                }
                driver_notification=self.env['notification.list'].create(driver_content)
                one_signal_data = rec.env['one.signal.master'].search([('driver_id','=',driver.id)])                  
                for data in one_signal_data:
                    doc_key_idss = data.key
                    signal_val = data.signal_type
                    user_mode=data.user_mode
                    
                    if signal_val=='android' and user_mode=='driver':
                        url = "https://onesignal.com/api/v1/notifications"

                        payload = {
                                "include_player_ids":[doc_key_idss],
                                "app_id":"7ca2c609-3ff3-4da3-a133-430e499d3250",
                                "contents": {"en": f"{rec.content}"},
                                "headings": {"en": "Ratepesu"},
                                "data": {"foo": "bar"},
                                "big_picture": f"https://rettupesu.mo.vc/web/image?model=push.notification&id={self.id}&field=image",
                                "name": "INTERNAL_CAMPAIGN_NAME"
                                }

                        headers = {
                                "Authorization": "Basic M2E1MTkwMTQtOGI5Yy00MTJlLThkZjgtODc1NmE4YmRhMTcz",
                                'Content-Type': 'application/json; charset=utf-8',
                            }
                        response = requests.post(url, json=payload, headers=headers)
                        
