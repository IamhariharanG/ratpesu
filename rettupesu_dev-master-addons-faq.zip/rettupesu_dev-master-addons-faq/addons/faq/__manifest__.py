{
    'name': 'FAQ',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'FAQ',
    'depends': ['base','mail','helpdesk','product'],
    'data': [

          'views/faq_categories.xml',
          'views/faq_entry.xml',
          'security/ir.model.access.csv',
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
