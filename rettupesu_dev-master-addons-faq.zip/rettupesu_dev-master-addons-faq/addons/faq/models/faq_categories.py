from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Helpdeskcategories(models.Model):
    _name = 'faq.categories'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin', "image.mixin"]
    _description = "FAQ Categories" 
   
    name = fields.Char(string="Name",required=True,track_visibility='onchange')
    user_id = fields.Many2one('res.users', string='User',default=lambda self: self.env.user.id,readonly="1")
    is_user=fields.Boolean(string="Is User",track_visibility='onchange')
    is_driver=fields.Boolean(string="Is Driver",track_visibility='onchange')
    category_image=fields.Binary(string="Image",attachment=True)


    
    