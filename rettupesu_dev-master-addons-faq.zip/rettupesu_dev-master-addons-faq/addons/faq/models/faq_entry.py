from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Frequentyaskedquestions(models.Model):
    _name = 'faq.entry' 
    _rec_name='name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Frequently Asked Questions'

    sequence_num=fields.Integer(string="Serial No",required=True,track_visibility='onchange')
    name = fields.Char(string='Question', required=True)
    answer = fields.Text(string='Answer', required=True)
    category_id=fields.Many2one('faq.categories',string="Category",required=True)
    state = fields.Selection([('active', 'Active'),('in_active', 'In Active')],string='Status',required=True,default='active',track_visibility='onchange')
    user_id = fields.Many2one('res.users', string='User',default=lambda self: self.env.user.id,readonly="1")
    is_active=fields.Boolean(string="Active",default=True,required=True,readonly=True)
   

    def active(self):
        for rec in self:
            rec.is_active=True
            rec.state='active'

    def in_active(self):
        for rec in self:
            rec.is_active=False
            rec.state='in_active'  
    