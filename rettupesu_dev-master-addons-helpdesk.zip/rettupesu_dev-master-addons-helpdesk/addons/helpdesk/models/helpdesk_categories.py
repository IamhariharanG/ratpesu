from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Helpdeskcategories(models.Model):
    _name = 'helpdesk.categories'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Helpdesk Categories" 
   
    name = fields.Char(string="Name",required=True,track_visibility='onchange')
   

    
    