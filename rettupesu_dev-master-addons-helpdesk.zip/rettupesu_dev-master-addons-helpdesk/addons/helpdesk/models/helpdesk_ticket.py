from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Helpdeskticket(models.Model):
    _name = 'helpdesk.ticket'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Helpdesk Ticket " 
   
    name = fields.Char(string="Name",track_visibility='onchange',default="New")
    replied_status = fields.Selection([('replied', 'Customer Replied'),('not_replied', 'Customer Not replied')],string='Replied Status',default='not_replied',track_visibility='onchange')
    ticket_type_id=fields.Many2one('helpdesk.ticket.type',string="Ticket Type",track_visibility='onchange')
    team_id=fields.Many2one('helpdesk.team',string="Team",track_visibility='onchange')
    user_id=fields.Many2one('res.users',string="Team Head",compute='team_head_detailes',store=True,track_visibility='onchange')
    assign_user_id=fields.Many2one('res.users',string="Assigned User",track_visibility='onchange')
    subject_id=fields.Many2one('helpdesk.subject.type',string="Ticket Subject Type",track_visibility='onchange')
    categories_id=fields.Many2one('helpdesk.categories',string="Category",track_visibility='onchange')
    sub_categories_id=fields.Many2one('helpdesk.subcategories',string="Sub Category",track_visibility='onchange')
    tag_ids=fields.Many2many('helpdesk.tag',string="Tags",track_visibility='onchange')
    priority_id=fields.Many2one('helpdesk.priorities',string="Priority",track_visibility='onchange')
    default_user_id = fields.Many2one('res.users', string='User',default=lambda self: self.env.user.id,readonly="1")
   
    partner_id=fields.Many2one('res.partner',string='Partner',track_visibility='onchange')
    person_name=fields.Char(string="Person Name",compute='partner_details',store=True,track_visibility='onchange')
    person_email=fields.Char(string="Email",track_visibility='onchange')
    reply_date=fields.Datetime(string="Replied Date",track_visibility='onchange')

    description=fields.Text(string="Description(Issue)",required=True,track_visibility='onchange')

    customer_feedback=fields.Text(string="Customer Feedback",track_visibility='onchange')
    customer_rating = fields.Selection([('0', 'No Rating'),('1', 'Ok'),('2', 'Good'),('3', 'High'),('4', 'Very High'),('5', 'Excellent')],string='Customer Rating',track_visibility='onchange')
  
    stage_id=fields.Many2one('helpdesk.stage',string="Stage",track_visibility='onchange',default=7,group_expand='_expand_stages')
   
    passenger_id=fields.Many2one('user.master',string="Passenger Name",track_visibility='onchange')
    driver_id=fields.Many2one('vb.driver.master',string="Driver Name",track_visibility='onchange')

    user_type=fields.Selection([('passenger','Passenger'),('driver','Driver')],string='User Type',track_visibility='onchange') 

    helpdesk_ticket_line=fields.One2many('helpdesk.ticket.line','line_id',string='Helpdesk Line',ondelete='cascade')
    
    # @api.onchange('team_id')
    # def _onchange_user_id(self):
    #     if self.user_id:
    #         for rec in self:
    #             record=self.env['helpdesk.team'].search([('user_id','=',rec.user_id.id)])
    #             for line in record:
    #                 # raise ValidationError(line.user_group_ids.ids)
    #                 return {'domain': {'model': [('assign_user_id', 'in', line.user_group_ids.ids)]}}

    
    def helpdesk_sequence(self):
        self.name = f"{'TICKET'}{self.env['ir.sequence'].next_by_code('helpdesk.sequence.create')}"

    def _expand_stages(self, states, domain, order):
        stage_ids = self.env['helpdesk.stage'].search([])
        return stage_ids       

    @api.depends('partner_id')  
    def partner_details(self):
        if self.partner_id:
            for rec in self:
                rec.person_name=rec.partner_id.name  
                rec.person_email=rec.partner_id.email  
        else:
            self.person_name=None
            self.person_email=None

    @api.depends('team_id')  
    def team_head_detailes(self):
        if self.team_id:
            for rec in self:
                rec.user_id=rec.team_id.user_id      
        else:
            self.user_id=None
    
    def approve(self):
        # self.stage_id=8
        if self.assign_user_id:
            channel=self.env['mail.channel'].search([('ticket_id','=',self.id)])
            if channel:
                channel.write({'channel_last_seen_partner_ids': [(0, 0, {'partner_id': self.assign_user_id.partner_id.id})]})

    def cancel(self):
        for rec in self:
            rec.stage_id=9
           
    def done(self):
        for rec in self: 
            rec.stage_id=10
          
    def close(self):
        for rec in self:
            rec.stage_id=11
           
    def reopen(self):
        for rec in self:
            rec.stage_id=12

    def helpdesk_channel_creation(self,ticket_id=None):
        ticket_id=self.search([('id','=',ticket_id)])
        customer_id=ticket_id.passenger_id.id
        driver_id=ticket_id.driver_id.id

        driver_read = self.env['vb.driver.master'].search([('id','=',int(driver_id))])
        driver_partner_id=driver_read.partner_id.id

        customer_read = self.env['user.master'].search([('id','=',int(customer_id))])
        customer_partner_id=customer_read.partner_id.id
        
        data = {
                'name' : f"Helpdesk{ticket_id.id}-Chat",
                'public' : 'groups',
                'ticket_id':ticket_id.id
                }
        create_channel = self.env['mail.channel'].sudo().create(data)
        if driver_partner_id:
            members = [(5,0,0)]
            line_data = {
                            'partner_id' :driver_partner_id,
                        }
            members.append((0,0,line_data))
            create_channel.channel_last_seen_partner_ids=members

        if customer_partner_id:
            members = [(5,0,0)]
            line_data = {
                            'partner_id' :customer_partner_id,
                        }
            members.append((0,0,line_data))
            create_channel.channel_last_seen_partner_ids=members    

class Helpdeskticketline(models.Model):
    
    _name='helpdesk.ticket.line'
    _rec_name='attachment'
    
    line_id=fields.Many2one('helpdesk.ticket',string="Line",ondelete='cascade')
    s_no=fields.Integer(string="S.No",compute='serial_number_data_so')
    partner_id=fields.Many2one('res.partner',string='Customer name',related='line_id.partner_id')
    attachment=fields.Many2many('ir.attachment',string="Document")
    attachment_date=fields.Date(string='Attachment Create Date',compute='attachment_create_date',store=True)
    user_id = fields.Many2one('res.users', string='User',default=lambda self: self.env.user.id)
           
    @api.depends('line_id.helpdesk_ticket_line')
    def serial_number_data_so(self):
        for rec in self:
            no=0
            rec.s_no = no
            for line in rec.line_id.helpdesk_ticket_line:
                no +=1
                line.s_no = no  

    @api.depends('attachment')  
    def attachment_create_date(self):
        for rec in self:
            if rec.attachment:
                rec.attachment_date=date.today()  
            else:
                rec.attachment_date=None
                 
    class Booking_inherit_mailchannels(models.Model):
        _inherit = 'mail.channel'

        ticket_id=fields.Many2one('helpdesk.ticket',string="Ticket")                                
 