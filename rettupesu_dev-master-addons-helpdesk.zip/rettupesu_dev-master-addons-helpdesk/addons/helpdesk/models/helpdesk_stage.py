from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Helpdeskstage(models.Model):
    _name = 'helpdesk.stage'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Helpdesk Tag" 
   
    name = fields.Char(string="Name",required=True,track_visibility='onchange')
    sequence_num=fields.Integer(string="Serial No",required=True,track_visibility='onchange')
    is_new=fields.Boolean(string="New",track_visibility='onchange')
    is_progress=fields.Boolean(string="In Progress",track_visibility='onchange')
    is_cancel=fields.Boolean(string="Cancelled",track_visibility='onchange')
    is_done=fields.Boolean(string="Done",track_visibility='onchange')
    is_close=fields.Boolean(string="Closed",track_visibility='onchange')
    is_reopen=fields.Boolean(string="Reopened",track_visibility='onchange')
    is_active=fields.Boolean(string="Active",track_visibility='onchange')
   
 
   
   
   

    
    