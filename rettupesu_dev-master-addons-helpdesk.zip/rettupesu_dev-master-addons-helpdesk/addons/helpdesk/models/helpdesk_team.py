from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError

class Helpdeskteam(models.Model):
    _name = 'helpdesk.team'
    _rec_name = 'name'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Helpdesk Team" 
   
    name = fields.Char(string="Name",required=True,track_visibility='onchange')
    user_id = fields.Many2one("res.users",string="Team Head",required=True,track_visibility='onchange')
    user_group_ids=fields.Many2many("res.users",string="Team Members",track_visibility='onchange')

    
    