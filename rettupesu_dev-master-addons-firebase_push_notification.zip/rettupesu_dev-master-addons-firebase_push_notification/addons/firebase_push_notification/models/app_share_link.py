from odoo import models, fields, api
from datetime import datetime
import requests
import json


class app_share_link(models.Model):
    _name='share.link'
    _rec_name='name'
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    _description = "Notification"

    name= fields.Char(string="Link",required=True)
    content = fields.Text(string="Content",track_visibility='onchange')
    type_users = fields.Selection([('driver','Driver'),('user','User'),('admin','Admin')],string = 'Type')
    
    