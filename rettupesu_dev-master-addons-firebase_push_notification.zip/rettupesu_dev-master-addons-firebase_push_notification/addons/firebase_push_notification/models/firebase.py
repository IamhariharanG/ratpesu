from odoo import models, fields, api
from datetime import datetime
import requests
import json


class notification_list(models.Model):
    _name='notification.list'
    _rec_name='name'
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    _description = "Notification"

    name= fields.Char(string="Name",required=True)
    description = fields.Html(string="Description",track_visibility='onchange')
    #vehicle booking management notification  status selection field 

    status_id = fields.Selection([('user_registration','User Registration'),
                                  ('user_login','User Login'),
                                  ('offer_notification','Offer Notification'),
                                  ('booking_pending','Booking Pending'),
                                  ('booking_waiting','waiting for driver'),
                                  ('confirmed','Confirmed'),
                                  ('booked','Booked'),
                                  ('cancel', 'Cancelled'),
                                  ('rescheduling','Rescheduling'),
                                  ('paid','Paid')],string='Status',track_visibility='onchange')
    
    read_status = fields.Selection([('read','Readed'),('un_read','Un Read')],string='View',default="un_read",track_visibility='onchange')
    res_users = fields.Many2one('res.users',string='Users')
    res_partner_id = fields.Many2one('res.partner',string='Partner')
    date = fields.Date(string="Date",default=datetime.now())
    image = fields.Binary(string="Image")
    notification_image = fields.Binary(string="Image")

    
    manager = fields.Boolean(string='Is driver')
    user = fields.Boolean(string='Is User')
    assigned_user = fields.Many2one('res.users',string='Assigned Users')
    
    driver_id=fields.Many2one('vb.driver.master',string="Driver")
    customer_id=fields.Many2one('user.master',string="Customer")

    booking_id = fields.Many2one('vb.book.master',string="Booking ID")
    background_image = fields.Image(string="Background Image")
    # image_notification = fields.Image(string="Notification Image")

    @api.model
    def create(self,vals):
        result = super(notification_list,self).create(vals)
        if result.status_id:
            notification_image_orm = self.env['notification.list.image'].search([('name','=',result.status_id)])
            result.background_image = notification_image_orm.image
        return result
class signal_master(models.Model):

    _name = 'one.signal.master'
    _rec_name = 'user_id'

    user_id = fields.Many2one('res.users',string='User Name')
    signal_type= fields.Selection([('android',"Android"),('ios',"IOS")],string="Signal Type")
    key = fields.Char('Key ID')
    
    #user
    user_mode= fields.Selection([('passenger',"Passenger"),('driver',"Driver")])
    driver_id = fields.Many2one('vb.driver.master',string='Driver')
    passenger_id = fields.Many2one('user.master',string='Passenger')
    
class createOtp(models.Model):
    _name='create.otp'
    _rec_name = 'phone_number'
    
    phone_number = fields.Char(string="Phone Number")
    otp_number = fields.Char(string="Otp")
    expire_date= fields.Float(string= "Expire Date")
    type_users = fields.Selection([('driver','Driver'),('user','User'),('admin','Admin')],string = 'Type')