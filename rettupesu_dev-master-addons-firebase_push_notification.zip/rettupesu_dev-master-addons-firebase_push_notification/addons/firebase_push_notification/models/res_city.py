from odoo import models, fields, api
from datetime import datetime
import requests
import json


class city_data(models.Model):
    _name = 'res.city'
    _rec_name = 'city_name'
    _order = "city_name"

    city_name = fields.Char(string='City Name')
    state_id = fields.Many2one('res.country.state',string='State')
    country_id = fields.Many2one('res.country',string='Country')
