from odoo import models, fields, api
from datetime import date

class CouponInherit(models.Model):
    _inherit = 'coupon.coupon'

    @api.model
    def create(self,vals):
        result = super(CouponInherit,self).create(vals)
        user_orm = self.env['res.users'].search([('partner_id.id','=',result.partner_id.id)])
        user_master_orm = self.env['user.master'].search([('partner_id.id','=',result.partner_id.id)])
        data = {
                    'name' : f"Coupon Created for Customer {result.partner_id.name}",
                    'status_id' : "offer_notification",
                    'read_status' : "un_read",
                    'date' : date.today(),
                    'res_partner_id' : result.partner_id.id,
                    'res_users' : user_orm.id,
                    'user' : True,
                    'description' : f"Hello {result.partner_id.name} Your Coupon Created Successfully."
                }
        if user_master_orm:
            data['customer_id'] = user_master_orm.id
        create_push = self.env['notification.list'].create(data)
        return result
        
    
    